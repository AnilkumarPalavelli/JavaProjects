/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercises;
import java.util.Random;

/**
 *
 * @author Anilkumar Palavelli_S549406
 */
public class Ex3_Palavelli_A {

    /**
     * @param args the command line arguments
     */
    public static int throwDice1( ) 
    {
        Random rand1=new Random();
        return rand1.nextInt(15-6)+6;
        
    }
    public static int throwDice2( ) 
    {
        Random rand2=new Random();
        return rand2.nextInt(6-1)+1;
        
    }
    private static int sumDice1Dice2( int value1,int value2)
    {
        return value1+value2;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        int value1= throwDice2( );
        int value2=throwDice1();
        int sum=sumDice1Dice2(value1,value2);
        System.out.println(" Dice1: "+value2);
        System.out.println(" Dice2: "+value1);
        System.out.println(" The sum of Dice1 and Dice 2 is:  "+sum);
        if(sum>=10)
        {
            System.out.println("Free passage");
        }
        else
        {
            System.out.println("Pay a fee: "+sum*2+"="+sum*2*0.10);
        }
        
    }
    
}
    
    
