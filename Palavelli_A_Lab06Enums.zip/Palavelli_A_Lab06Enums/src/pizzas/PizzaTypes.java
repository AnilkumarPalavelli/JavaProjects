/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 * Class: 44542-04 Object Oriented Programming
 *
 * @author Anil Palavelli 
 * Description: Making sure everything works Due:
 * 10/21/22 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public enum PizzaTypes {
    
  /**
     * The singleton instance for the Pizza Types of Handtossed Pizza.
     */
    HANDTOSSED_PIZZA(8.50,11.50,14.50),
    /**
     * The singleton instance for the Pizza Types of Pan Pizza.
     */
    PAN_PIZZA(6.50,9.50,12.50);
 private final double smallPizzaPrice;
 private final double mediumPizzaPrice;
 private final double largePizzaPrice;
    /**
     * Constructor to initialize instance variables
     * @param smallPizzaPrice
     * @param mediumPizzaPrice
     * @param largePizzaPrice 
     */
    private PizzaTypes(double smallPizzaPrice, double mediumPizzaPrice, double largePizzaPrice) {
        this.smallPizzaPrice = smallPizzaPrice;
        this.mediumPizzaPrice = mediumPizzaPrice;
        this.largePizzaPrice = largePizzaPrice;
    }

    /**
     * Getter method to retrieve price of small size pizza price
     * @return price of small size pizza price
     */
   public double getSmallPizzaPrice() {
        return smallPizzaPrice;
    }

   /**
     * Getter method to retrieve price of medium size pizza price
     * @return price of medium size pizza price
     */
    public double getMediumPizzaPrice() {
        return mediumPizzaPrice;
    }

    /**
     * Getter method to retrieve price of large size pizza price
     * @return price of large size pizza price
     */
    public double getLargePizzaPrice() {
        return largePizzaPrice;
    }  
    
}
