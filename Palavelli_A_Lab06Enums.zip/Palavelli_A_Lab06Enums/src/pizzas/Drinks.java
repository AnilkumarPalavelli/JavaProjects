/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 * Class: 44542-04 Object Oriented Programming
 *
 * @author Anil Palavelli 
 * Description: Making sure everything works Due:
 * 10/21/22 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public enum Drinks {
/**
     * The singleton instance for the Drinks of Fountain soda.
     */
    FOUNTAIN_SODA_20_OZ(1.99),
    /**
     * The singleton instance for the Drinks of Red bull.
     */
    RED_BULL(5.29),
    /**
     * The singleton instance for the Drinks of Sparkling juice.
     */
    IZZE_SPARKLING_JUICE(3.79),
    /**
     * The singleton instance for the Drinks of Fresh Brewed Iced tea.
     */
    FRESH_BREWED_ICED_TEA(3.99),
    /**
     * The singleton instance for the Drinks of Water.
     */
    WATER(0.00);
    private double drinkPrice;
    /**
     * constructor to initiate drink price variable
     * @param drinkPrice 
     */
    private Drinks(double drinkPrice) {
        this.drinkPrice = drinkPrice;
    }

    /**
     * Getter method to retrieve drink price
     * @return drink price
     */
    public double getDrinkPrice() {
        return drinkPrice;
    }   
}
