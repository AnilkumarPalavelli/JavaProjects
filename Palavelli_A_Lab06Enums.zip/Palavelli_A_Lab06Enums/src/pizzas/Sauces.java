/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 * Class: 44542-04 Object Oriented Programming
 *
 * @author Anil Palavelli 
 * Description: Making sure everything works Due:
 * 10/21/22 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public enum Sauces {
    /**
     * The singleton instance for the Sauces of Pesto
     */
    PESTO(0.10),
    /**
     * The singleton instance for the Sauces of Tomato
     */
    TOMATO(0.12),
    /**
     * The singleton instance for the Sauces of Bechamel
     */
    BECHAMEL(0.20),
    /**
     * The singleton instance for the Sauces of BBQ
     */
    BBQ(0.30),
    /**
     * The singleton instance for the Sauces of Hummus
     */
    HUMMUS(0.15),
    /**
     * The singleton instance for the Sauces of Marinara
     */
    MARINARA(0.20),
    /**
     * The singleton instance for the Sauces of Tapenade
     */
    TAPENADE(0.12),
    /**
     * The singleton instance for the Sauces of Pumpkin pizza sauce
     */
    PUMPKIN_PIZZA_SAUCE(0.20),
    /**
     * The singleton instance for the Sauces of no sauce
     */
    NO_SAUCE(0.00);
    private final double priceOfSauce;
    /**
     * Constructor to initiate instance variables
     * @param priceOfSauce 
     */
  private Sauces(double priceOfSauce){
    this.priceOfSauce=priceOfSauce;
    }
  
  /**
   * Getter method to retrieve sauce price
   * @return price of sauce
   */
    public double getPriceOfSauce() {
        return priceOfSauce;
    }
}
