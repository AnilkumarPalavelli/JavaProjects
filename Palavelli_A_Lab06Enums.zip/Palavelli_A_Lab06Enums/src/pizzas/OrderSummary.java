/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

import java.util.ArrayList;

/**
 * Class: 44542-04 Object Oriented Programming
 *
 * @author Anil Palavelli 
 * Description: Making sure everything works Due:
 * 10/21/22 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public class OrderSummary {
    private  ArrayList<Order> orders=new ArrayList<Order>();
  /**
   * NO arg constructor
   */
  public OrderSummary(){
      
  }
    /**
     * Getter method to retrieve orders
     * @return orders
     */
    public ArrayList<Order> getOrders() {
        return orders;
    }
    /**
     * Method to add orders to orders arraylist
     * @param order 
     */
  public void addAOrder(Order order){
      orders.add(order);
  }
  /**
   * Method to calculate total cost of the order
   * @param orderDate
   * @return  total cost of order
   */
  public double calcTotalCostOfAllOrders(String orderDate){
      double totalCost=0.0;
      totalCost=totalCost+orders.get(0).getTotalCost(orderDate);
      return totalCost;
  }
  /**
   * Method to calculate total cost with tax
   * @param orderDate
   * @return total cost with tax
   */
  public double calcTotalBillWithTax(String orderDate){
      double billWIthTax=orders.get(0).getTotalCost(orderDate)-orders.get(0).calcDiscount(orderDate)+(orders.get(0).getTotalCost(orderDate)-orders.get(0).calcDiscount(orderDate))*(8.6/100);
    return Math.floor(billWIthTax*100.0)/100.0;
       
  }
  /**
   * Method to retrieve receipt data
   * @param orderDate
   * @return receipt data
   */
  public String printReceipt(String orderDate){
       String receipt="";
       double tax=(orders.get(0).getTotalCost(orderDate)-orders.get(0).calcDiscount(orderDate))*(8.6/100);
      receipt="*****  "+orderDate+", "+Days.getOrderDayOfWeek(orderDate)+"  ****** \n"
              + orders.get(0).toString(orderDate)+"\n-----------------------------------------------------------------"
                         +"\n       Order Total :   $"+orders.get(0).getTotalCost(orderDate)
                         +"\n       Discount@50 :   $"+orders.get(0).calcDiscount(orderDate)
                         +"\n       Tax@8.6 :   $"+Math.floor(tax*Math.pow(10, 2))/Math.pow(10, 2)
                         +"\n       Total Amount with tax : $"+calcTotalBillWithTax(orderDate)
                         +"\n-----------------------------------------------------------------";
             
      return receipt;
  }
}
