/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 * Class: 44542-04 Object Oriented Programming
 *
 * @author Anil Palavelli 
 * Description: Making sure everything works Due:
 * 10/21/22 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public enum Sides {
  /**
     * The singleton instance for the Sides of Garlic cheese bread
     */
    GARLIC_CHEESEBREAD(5.99,20.99,30.99),
    /**
     * The singleton instance for the Sides of Chef salad
     */
    CHEFSALAD(3.99,15.99,25.99),
    /**
     * The singleton instance for the Sides of Ranch stix
     */
    RANCH_STIX(2.99,6.99,13.99),
    /**
     * The singleton instance for the Sides of Ranch pesto wedges
     */
    RANCH_POTATO_WEDGES(3.99,11.99,22.99),
    /**
     * The singleton instance for the Sides of Mashed potatoes
     */
    MASHED_POTATOES(6.99,15.99,30.99),
    /**
     * The singleton instance for the Sides of Ranch chips
     */
    RANCH_CHIPS(4.99,16.99,35.99),
    /**
     * The singleton instance for the Sides of Parmesan broccoli
     */
    PARMESAN_BROCCOLI(3.99,8.99,20.99),
    /**
     * The singleton instance for the Sides of onion rings
     */
    ONION_RINGS(1.99,5.49,19.49),
    /**
     * The singleton instance for the Sides of no sides
     */
    NO_SIDES(0.00,0.00,0.00);

    private final double smallSidesPrice;
        private final double  familySidesPrice;
        private final double partySidesPrice;
        /**
         * Constructor to initiate instance variables
         * @param smallSidesPrice
         * @param familySidesPrice
         * @param partySidesPrice 
         */
        private Sides(double smallSidesPrice,double familySidesPrice,double partySidesPrice){
        this.smallSidesPrice=smallSidesPrice;
        this.familySidesPrice=familySidesPrice;
        this.partySidesPrice=partySidesPrice;
        }

    /**
     * Getter method to retrieve small sides price
     * @return small sides price
     */
        public double getSmallSidesPrice() {
        return smallSidesPrice;
    }

    /**
     * Getter method to retrieve family size sides price
     * @return family size sides price
     */
    public double getFamilySidesPrice() {
        return familySidesPrice;
    }

    /**
     * Getter method to retrieve party size sides price
     * @return party size sides price
     */
    public double getPartySidesPrice() {
        return partySidesPrice;
    }
       /**
 * Class: 44542-04 Object Oriented Programming
 *
 * @author Anil Palavelli 
 * Description: Making sure everything works Due:
 * 10/21/22 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
   enum Cheese{
     /**
     * The singleton instance for the Cheese of American cheese
     */
     AMERICAN_CHEESE(0.10),
     /**
     * The singleton instance for the Cheese of Cheddar cheese
     */
     CHEDDAR_CHEESE(0.12),
     /**
     * The singleton instance for the Cheese of Cheddar jack cheese
     */
     CHEDDAR_JACK_CHEESE(0.20),
     /**
     * The singleton instance for the Cheese of Pepper jack cheese
     */
     PEPPER_JACK_CHEESE(0.30),
     /**
     * The singleton instance for the Cheese of Queso cheese
     */
     QUESO_CHEESE(0.15),
     /**
     * The singleton instance for the Cheese of Swiss cheese
     */
     SWISS_CHEESE(0.20),
     /**
     * The singleton instance for the Cheese of Blue cheese
     */
     BLUE_CHEESE(0.12),
     /**
     * The singleton instance for the Cheese of ranch
     */
     RANCH(0.20),
     /**
     * The singleton instance for the Cheese of No cheese
     */
     NO_CHEESE(0.00);
     
    private final double CheesePrice;
    /**
      * Getter method to retrieve cheese price
      * @return cheese price
      */
     public double getCheesePrice() {
        return CheesePrice;
    }
     /**
      * Constructor to initiate instance variables
      * @param CheesePrice 
      */
    private Cheese(double CheesePrice){
    this.CheesePrice=CheesePrice;
}
   }
}
