/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Class: 44542-04 Object Oriented Programming
 *
 * @author Anil Palavelli 
 * Description: Making sure everything works Due:
 * 10/21/22 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public class Days {
    /**
     * no arg constructor
     */
   private Days() {
    }
   /**
    * This method return day of the week using the date provided
    * @param orderDate
    * @return day of the week
    */
   public static String getOrderDayOfWeek(String orderDate){
       DateTimeFormatter format = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        LocalDate localdate = LocalDate.parse(orderDate, format);
        DayOfWeek dayOfWeek = DayOfWeek.from(localdate);
        return dayOfWeek.name();
   }
   /**
    * This method checks if given date falls on Saturday or Sunday
    * @param orderDate
    * @return discount day
    */
   public static boolean isDiscountDay(String orderDate){
      boolean flag = false;
      flag = getOrderDayOfWeek(orderDate).equalsIgnoreCase("SATURDAY") || getOrderDayOfWeek(orderDate).equalsIgnoreCase("SUNDAY");
        return flag;
   } 
}
