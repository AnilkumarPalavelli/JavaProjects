/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 * Class: 44542-04 Object Oriented Programming
 *
 * @author Anil Palavelli 
 * Description: Making sure everything works Due:
 * 10/21/22 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public enum Desserts {
/**
     * The singleton instance for the dessert of Chocolate fudge cake.
     */
    CHOCOLATE_FUDGE_CAKE(10.99),
    /**
     * The singleton instance for the dessert of Cheese cake bites.
     */
    CHEESECAKE_BITES(12.49),
    /**
     * The singleton instance for the dessert of Dessert Nachos.
     */
    DESSERT_NACHOS(9.49),
    /**
     * The singleton instance for the dessert of Loaded Ice cream.
     */
    LOADED_ICE_CREAM(5.49),
    /**
     * The singleton instance for the dessert of No Desserts.
     */
    NO_DESSERTS(0.00);
    private double dessertPrice;
    /**
    * Constructor to initiate dessert price 
    * @param dessertPrice 
    */
    private Desserts(double dessertPrice) {
        this.dessertPrice = dessertPrice;
    }
    /**
    * Getter method to retrieve dessert price
    * @return dessertPrice
    */
    public double getDessertPrice() {
        return dessertPrice;
    } 
}
