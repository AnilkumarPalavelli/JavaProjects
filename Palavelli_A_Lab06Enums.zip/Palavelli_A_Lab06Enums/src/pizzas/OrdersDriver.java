/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Class: 44542-04 Object Oriented Programming
 *
 * @author Anil Palavelli 
 * Description: Making sure everything works Due:
 * 10/21/22 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public class OrdersDriver {
 /**
     * Main method  
     * @param args 
     * @throws FileNotFoundException 
     */
     public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
    Scanner scan=new Scanner(new File("input.txt"));
   System.out.println("*******************");
   System.out.println("******** Pizza Hut *******");
   System.out.println("*******************");
   while (scan.hasNext()) {
                   OrderSummary orderSum=new OrderSummary();
                  String orderdate= scan.nextLine();
                  Days.getOrderDayOfWeek(orderdate);
                  String pizza=scan.nextLine();
                  PizzaTypes pizzaType=PizzaTypes.valueOf(pizza.replace(" ", "_").toUpperCase());
                  String pizzaSize=scan.next();
                  int pizzaCount=scan.nextInt();
                  scan.nextLine();
                  Sauces sauceType=Sauces.valueOf(scan.nextLine().replace(" ", "_").toUpperCase());
                  String sides=scan.nextLine();
                  Sides side=Sides.valueOf(sides.substring(0,sides.indexOf("-")-1).replace(" ", "_").toUpperCase());
                  String sideSize=sides.substring(sides.indexOf("-")+2);
                  Sides.Cheese cheese=Sides.Cheese.valueOf(scan.nextLine().replace(" ", "_").toUpperCase());
                  Drinks drink=Drinks.valueOf(scan.nextLine().replace(" ", "_").toUpperCase());
                  Desserts dessert=Desserts.valueOf(scan.nextLine().trim().replace(" ", "_").toUpperCase());
                  Order order=new Order(pizzaType, pizzaSize, pizzaCount, sauceType, side, sideSize,drink , cheese, dessert);
                  orderSum.addAOrder(order);
                  System.out.println(orderSum.printReceipt(orderdate));
        }
        }
    
}
