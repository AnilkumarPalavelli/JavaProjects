/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

import pizzas.Sides.Cheese;

/**
 * Class: 44542-04 Object Oriented Programming
 *
 * @author Anil Palavelli 
 * Description: Making sure everything works Due:
 * 10/21/22 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public class Order {
private  PizzaTypes pizzasName;
 private String pizzasSize;
 private  int quantity;
 private Sauces sauce;
 private Sides side;
 private String sideSize;
 private Drinks drink;
 private Cheese cheese;
 private Desserts dessert;
 private double cost;
/**
 * Constructor to initialize instance variables
 * @param pizzasName
 * @param pizzasSize
 * @param quantity
 * @param sauce
 * @param side
 * @param sideSize
 * @param drink
 * @param cheese
 * @param dessert 
 */
    public Order(PizzaTypes pizzasName, String pizzasSize, int quantity, Sauces sauce, Sides side, String sideSize, Drinks drink, Cheese cheese, Desserts dessert) {
        this.pizzasName = pizzasName;
        this.pizzasSize = pizzasSize;
        this.quantity = quantity;
        this.sauce = sauce;
        this.side = side;
        this.sideSize = sideSize;
        this.drink = drink;
        this.cheese = cheese;
        this.dessert = dessert;
    }

    /**
     * Getter method to retrieve pizza name 
     * @return pizza name
     */
    public PizzaTypes getPizzasName() {
        return pizzasName;
    }
    /**
     * Getter method to retrieve pizza size
     * @return pizza size
     */
    public String getPizzasSize() {
        return pizzasSize;
    }

    public int getQuantity() {
        return quantity;
    }

    /**
     * Getter method to retrieve sauce
     * @return sauce
     */
    public Sauces getSauce() {
        return sauce;
    }

    /**
     * Getter method to retrieve side
     * @return side
     */
    public Sides getSide() {
        return side;
    }

    /**
     * Getter method to retrieve side size
     * @return side size
     */
    public String getSideSize() {
        return sideSize;
    }

    /**
     * Getter method to retrieve drink
     * @return drink
     */
    public Drinks getDrink() {
        return drink;
    }

    /**
     * Getter method to retrieve cheese
     * @return cheese
     */
    public Cheese getCheese() {
        return cheese;
    }

    /**
     * Getter method to retrieve dessert
     * @return dessert
     */
    public Desserts getDessert() {
        return dessert;
    }

    /**
     * Getter method.retrieve cost
     * @return cost
     */
    public double getCost() {
        return cost;
    }
    /**
     * This method is used to return Dessert cost
     * @return dessert price
     */
   private double calcDessertCost(){
       
       return dessert.getDessertPrice();
   }
   /**
    * This method is used to return Sauce cost
    * @return sauce cost
    */
   private double calcSauceCost(){
       return sauce.getPriceOfSauce();
   }
   /**
    * This method is used to return cheese cost
    * @return Cheese cost
    */
   private double calcCheeseCost(){
       return cheese.getCheesePrice();
   } 
   /**
    * This method is used to return drink cost
    * @return drink price
    */
   private double calcDrinkCost(){
        return drink.getDrinkPrice();   
   }
   /**
    * This method is used to return side cost
    * @return side cost
    */
    private double calcSideCost(){
        if(sideSize.equalsIgnoreCase("family"))
            return side.getFamilySidesPrice();
        else if(sideSize.equalsIgnoreCase("Party"))
        return side.getPartySidesPrice();
        else
            return side.getSmallSidesPrice();
   }
    /**
     * This method is used to return pizza cost
     * @return pizza cost
     */
    public double calcPizzasCost(){
        if(pizzasSize.equalsIgnoreCase("Large"))
        return pizzasName.getLargePizzaPrice()*quantity;
        else if(pizzasSize.equalsIgnoreCase("Medium"))
            return pizzasName.getMediumPizzaPrice()*quantity;
        else
            return pizzasName.getSmallPizzaPrice()*quantity;
   }
    /**
     * This method is used to return discount 
     * @param orderDate
     * @return discount
     */
    public double calcDiscount(String orderDate){
         double discount=0.0;
        if(pizzasName.equals(pizzasName.HANDTOSSED_PIZZA )&& Days.isDiscountDay(orderDate) ){
                         discount =0.5*calcPizzasCost();  
          }
        else{
            discount=0.0;
        }
        return discount; 
   }
    /**
     * This method is used to return tota cost
     * @param orderDate
     * @return total cost
     */
    public double getTotalCost(String orderDate){
        cost=calcDessertCost()+calcSauceCost()+calcCheeseCost()+calcDrinkCost()+calcSideCost()+calcPizzasCost();
        return cost;
    }
    /**
     * toString method to retrieve receipt data
     * @param orderDate
     * @return receipt data
     */
    public String toString(String orderDate){
         return "PIZZA TYPE: " + pizzasName.toString().replace("_", " ") + "\n"
                + "PIZZA SIZE: " + pizzasSize.toUpperCase() + "\n"
                + "QUANTITY: " + quantity + "\n"
                + "SAUCE: " + sauce.toString().replace("_", " ") + "\n"
                + "SIDES: " + side.toString().replace("_", " ") + " (" + sideSize.toUpperCase() + ")\n"
                + "CHEESE: " + cheese.toString().replace("_", " ") + "\n"
                + "DRINKS: " + drink.toString().replace("_", " ") + "\n"
                + "DESSERTS: " + dessert.toString().replace("_", " ") + "\n"
                + "COST: " + (String.format("%.2f", (Math.round(getTotalCost(orderDate) * 100) / 100.0))) + "\n";
    }
}
