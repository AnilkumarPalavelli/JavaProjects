/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exhibition;

/**
 *
 * @author S549406
 */
public class Youth extends Exhibitor {
    private static final int PTS_NEEDED = 250;
    private static final int NUMBER_OF_EVENTS= 2;
    private int numEvents;

    public Youth() {
    }

    public Youth(int numEvents, String lastName, String firstName, int yearOfBirth, int points) {
        super(lastName, firstName, yearOfBirth, points);
        this.numEvents = numEvents;
    }
    
    

    
    

    @Override
    public boolean worldShowQualified() {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       if(super.getPoints()>PTS_NEEDED && numEvents >= NUMBER_OF_EVENTS)
           
           return true;
       else
           return false;
    }
    
    

}
