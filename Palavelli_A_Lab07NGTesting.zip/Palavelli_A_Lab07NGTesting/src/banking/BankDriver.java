/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Anilkumar Palavelli_S549406
 */
public class BankDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        //Note: (i). You can create any variables required within the main method but not as global/instance variables.
        //      (ii). The dates times provided for the transaction times are in yyyy-MM-dd HH:mm:ss
        // 1. Create an arraylist of Accounts and name it as accounts to store the list of accounts

        ArrayList<Account> accounts = new ArrayList<>();
        // 2. Create a scanner object and name it as sc to read the input from keyboard
        Scanner sc = new Scanner(new File("input.txt"));
        String s1 = null;
        String s2 = "";
        while (sc.hasNextLine()) {
            if (s1 == null) {
                s1 = sc.nextLine();
            } else {
                s1 = s2;
            }
            // 3. Read the values account type, first name, last name, date of birth from the input file

            String name = sc.nextLine();
            String firstName = name.substring(0, name.indexOf(" "));
            String lastName = name.substring(name.indexOf(" ") + 1);
            String dob = sc.nextLine();

            // 4. Create an Customer object.
            Customer cu = new Customer(dob, firstName, lastName);

            // 5. Create an Account object.
            long accountNumber = Long.parseLong(sc.nextLine());
            boolean hasLimitedWithdrawals = Boolean.parseBoolean(sc.nextLine());
            Account a = new Account(accountNumber, cu, hasLimitedWithdrawals);

            // 6. Print full name of the customer.
            System.out.println("------------------------------------------------------------");
            System.out.println("Name of the customer: " + cu.getFirstName() + " " + cu.getLastName());
            System.out.println("------------------------------------------------------------");
            s2 = sc.nextLine();
            while (!s2.equalsIgnoreCase("newAccount")) {
                //     a. Read trasaction and a create transaction object by initalizing the multiple argument constructor.
//System.out.println("s2::"+s2);
                String s3 = s2;

                String[] units = s3.split(" ");
                String transactionType = units[0];
                double amount = Double.parseDouble(units[1]);
                String date = units[2];
                int year = Integer.parseInt(date.substring(0, date.indexOf("-")));
                int month = Integer.parseInt(date.substring(date.indexOf("-") + 1, date.lastIndexOf("-")));
                int day = Integer.parseInt(date.substring(date.lastIndexOf("-") + 1));

                String time = units[3];
                int hours = Integer.parseInt(time.substring(0, time.indexOf(":")));
                int minutes = Integer.parseInt(time.substring(time.indexOf(":") + 1, time.lastIndexOf(":")));
                int seconds = Integer.parseInt(time.substring(time.lastIndexOf(":") + 1));

                LocalDateTime transactionTime = LocalDateTime.of(year, month, day, hours, minutes, seconds);
                Transaction t1 = new Transaction(transactionType, amount, transactionTime);
                //     b. call makeTransaction() method on account object.

                String s4 = a.makeTransaction(t1);
                //c. Print appropiate message upon completing each transaction based on return value of makeTransaction().
                //if makeTransaction returns "Insufficient Balance" print "Insufficient funds. Available funds: {funds}".
                //  where {funds} is the available funds on account.
                if (s4.equalsIgnoreCase("Insufficient Balance")) {
                    System.out.println("Insufficient funds. Available funds: " + a.getBalance());
                }
                //if makeTransaction returns "MaxTransactions" print "Exceeded number of withdrawals transactions. Number of available withdrawals per month: 6"

                if (s4.equalsIgnoreCase("MaxTransactions")) {
                    System.out.println("Exceeded number of withdrawals transactions. Number of available withdrawals per month: 6");
                }
                //if makeTransaction returns "Transaction Successful" then print "The balance after {transactionType} in dollars is {funds}"
                //  where {transactionType} is type of transaction.
                if (s4.equalsIgnoreCase("Transaction Successful")) {
                    System.out.println("The balance after " + transactionType + " in dollars is " + a.getBalance());
                }
                if (sc.hasNextLine()) {
                    s2 = sc.nextLine();
                } else {
                    break;
                }
            }

            // 10. Add Account object to accounts Arraylist.
            accounts.add(a);
        }
        System.out.println("********");
        System.out.println("*Invoke getNoofWithdrawals() on Account objects**");
        System.out.println("********");
        // Print "Invoke getNoofWithdrawals() on SavingsAccount objects"
        for (Account act : accounts) {
            // 11(a). For each Account from accounts, invoke getNoofWithdrawals() method on SavingsAccount objects
            // 11(b). Print number of withdrawls made in this month for each account.
            System.out.println(act.getCustomer().getFirstName() + " made " + act.getNoofWithdrawals() + " withdrawals in this month.");
        }
        System.out.println("*********");
        // Print "Invoke generateStatement() on all objects in accounts ArrayList"
        System.out.println("Invoke generateStatement() on all objects in accounts ArrayList");
        System.out.println("********");

        // 12. Invoke generateStatement() method on all objects in accounts ArrayList and print all account statements
        for (Account act : accounts) {
            System.out.println(act.generateStatement());
        }
    }

}
