/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.time.LocalDateTime;

/**
 *
 * @author Anilkumar Palavelli_S549406
 */
public class Transaction {

    private double additionalCharges;
    private double amount;
    private String status;
    private LocalDateTime transactionTime;
    private String transactionType;
/**
 * constructor with three parameters
 * @param transactionType
 * @param amount
 * @param transactionTime 
 */
    public Transaction(String transactionType, double amount, LocalDateTime transactionTime) {

        this.transactionType = transactionType;
        this.amount = amount;
        this.transactionTime = transactionTime;
    }
/**
 * getter method returns the AdditionalCharges
 * @return 
 */
    public double getAdditionalCharges() {
        return additionalCharges;
    }
/**
 * getter method returns the Amount
 * @return 
 */
    public double getAmount() {
        return amount;
    }
/**
 * getter method returns the Status
 * @return 
 */
    public String getStatus() {
        return status;
    }
/**
 * getter method returns the TransactionTime
 * @return 
 */
    public LocalDateTime getTransactionTime() {
        return transactionTime;
    }
/**
 * getter method returns the TransactionTime
 * @return 
 */
    public String getTransactionType() {
        return transactionType;
    }
/**
 * setter methods sets the additionalCharges
 * @param additionalCharges 
 */
    public void setAdditionalCharges(double additionalCharges) {
        this.additionalCharges = additionalCharges;
    }
/**
 * setter method sets the amount
 * @param amount 
 */
    public void setAmount(double amount) {
        this.amount = amount;
    }
/**
 * setter method sets the status
 * @param status 
 */
    public void setStatus(String status) {
        this.status = status;
    }
/**
 * setter method sets the transactionTime
 * @param transactionTime 
 */
    public void setTransactionTime(LocalDateTime transactionTime) {
        this.transactionTime = transactionTime;
    }
/**
 * setter method sets the transactionType
 * @param transactionType 
 */
    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }
/**
 * toString method returns
 * @return 
 */
    @Override
    public String toString() {
        return transactionType + " " + transactionTime + " " + amount + " " + additionalCharges + " " + status;
    }

}
