/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

/**
 *
 * @author S549406
 */
public class Customer {

    private String dob;
    private String firstName;
    private String lastName;
/**
 * constructor with three parameters
 * @param dob
 * @param firstName
 * @param lastName 
 */
    public Customer(String dob, String firstName, String lastName) {
        this.dob = dob;
        this.firstName = firstName;
        this.lastName = lastName;
    }
/**
 * getter method for dob
 * @return 
 */
    public String getDob() {
        return dob;
    }
/**
 * getter method for firstName
 * @return 
 */
    public String getFirstName() {
        return firstName;
    }
/**
 * getter method for return lastName
 * @return 
 */
    public String getLastName() {
        return lastName;
    }
/**
 * Setter method for sets the dob
 * @param dob 
 */
    public void setDob(String dob) {
        this.dob = dob;
    }
/**
 * setter method for sets the firstName
 * @param firstName 
 */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
/**
 * setter method for sets the lastName
 * @param lastName 
 */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
/**
 * toString method to return the Name and Date of Birth
 * @return 
 */
    @Override
    public String toString() {
        return "Name: " + lastName + ", " + firstName
                + "\nDate of Birth: " + dob;
    }

}
