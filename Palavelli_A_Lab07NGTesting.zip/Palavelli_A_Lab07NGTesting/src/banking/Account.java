/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.util.ArrayList;
import java.time.YearMonth;

/**
 *
 * @author Anilkumar Palavelli_S549406
 */
public class Account {

    private long accountNumber;
    private Customer customer;
    private double balance;
    private ArrayList<Transaction> transactions;
    private boolean hasLimitedWithdrawals;
    private static final double SAVING_INTEREST = 5.80;
/**
 * constructor with three parameters
 * @param accountNumber
 * @param customer
 * @param hasLimitedWithdrawals 
 */
    public Account(long accountNumber, Customer customer, boolean hasLimitedWithdrawals) {
        this.accountNumber = accountNumber;
        this.customer = customer;
        this.hasLimitedWithdrawals = hasLimitedWithdrawals;
        transactions = new ArrayList<>();
    }
/**
 * getter method returns the AccountNumber
 * @return 
 */
    public long getAccountNumber() {
        return accountNumber;
    }
/**
 * getter method returns the Customer
 * @return 
 */
    public Customer getCustomer() {
        return customer;
    }
/**
 * getter method returns the Balance
 * @return 
 */
    public double getBalance() {
        return balance;
    }

    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }
/**
 * getter method returns the HaslimitedWithdrawals
 * @return 
 */
    public boolean isHasLimitedWithdrawals() {
        return hasLimitedWithdrawals;
    }
/**
 * generateStatement method
 * @return 
 */
    public String generateStatement() {
        double interest = balance * SAVING_INTEREST / 100;
        String noOfTransactions;
        if (hasLimitedWithdrawals) {
            noOfTransactions = "7 Transactions";
        } else {
            noOfTransactions = "No Limit";
        }
        String output = customer.toString()
                + "\nAccount Number: " + getAccountNumber()
                + "\nAccount Information:-   Interest Rate: " + SAVING_INTEREST+ "%"
                + "\nTransaction Limit for withdrawal: " + noOfTransactions
                + "\n-------------------------------------------------------------------"
                + "\nTransaction Type" + "    " + " Transaction Time" + "         " + " Amount"
                + "\n          Additional Charges" + "           Status\n";
        for (Transaction tr : getTransactions()) {
            output += tr.toString() + "\n";
        }
        output += "\n---------------------------------------------------------------"
                + "\nCurrent Balance: " + Math.floor(getBalance() * Math.pow(10, 2)) / Math.pow(10, 2) + "        Interest: $" + Math.floor(interest * Math.pow(10, 2)) / Math.pow(10, 2)
                + "\n**********";

        return output;
    }
/**
 * NoofWithdrawalas Method
 * @return 
 */
    public int getNoofWithdrawals() {
        int currentMonth = YearMonth.now().getMonthValue();
        int a = 0;
        for (Transaction tr : transactions) {
            if ((currentMonth == tr.getTransactionTime().getMonthValue()) && tr.getTransactionType().equalsIgnoreCase("WITHDRAW")) {
                a++;
            }
        }
        return a;
    }
/**
 * makeTransaction method
 * @param transaction
 * @return 
 */
    public String makeTransaction(Transaction transaction) {
        String tr = transaction.getTransactionType();
        if (tr.equalsIgnoreCase("WITHDRAW")
                || tr.equalsIgnoreCase("ONLINEPURCHASE")) {
            if (balance < transaction.getAmount()) {
                transaction.setAdditionalCharges(0.0);
                transaction.setStatus("FAILED");
                transactions.add(transaction);
                return "Insufficient Balance";
            }
        }
        if (tr.equalsIgnoreCase("DEPOSIT")) {
            transaction.setAdditionalCharges(0.0);
            transaction.setStatus("SUCCESS");
            transactions.add(transaction);
            balance = balance + transaction.getAmount();
            return "Transaction Successful";
        } else if (tr.equalsIgnoreCase("ONLINEPURCHASE")) {
            transaction.setAdditionalCharges(1.99);
            transaction.setStatus("SUCCESS");
            transactions.add(transaction);
            balance = balance - (transaction.getAmount() + transaction.getAdditionalCharges());
            return "Transaction Successful";
        } else if (tr.equalsIgnoreCase("WITHDRAW")) {
            if (hasLimitedWithdrawals) {
                if (getNoofWithdrawals() > 5) {
                    transaction.setAdditionalCharges(0.0);
                    transaction.setStatus("FAILED");
                    transactions.add(transaction);
                    return "MaxTransactions";
                } else {
                    transaction.setAdditionalCharges(0.0);
                    transaction.setStatus("SUCCESS");
                    balance = balance - transaction.getAmount();
                    transactions.add(transaction);
                    return "Transaction Successful";
                }
            } else {
                if (getNoofWithdrawals() > 5) {
                    if (transaction.getAmount() * 0.01 > 2.59) {
                        transaction.setAdditionalCharges(transaction.getAmount() * 0.01);
                    } else {
                        transaction.setAdditionalCharges(2.59);
                    }

                    transaction.setStatus("SUCCESS");
                    balance = balance - transaction.getAmount() - transaction.getAdditionalCharges();
                    transactions.add(transaction);
                    return "Transaction Successful";
                } else {
                    transaction.setAdditionalCharges(0.0);
                    transaction.setStatus("SUCCESS");
                    balance = balance - transaction.getAmount();
                    transactions.add(transaction);
                    return "Transaction Successful";
                }
            }
        }

        return null;

    }
}

