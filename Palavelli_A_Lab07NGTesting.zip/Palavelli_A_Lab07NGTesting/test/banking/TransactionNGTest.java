/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.time.LocalDateTime;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Anilkumar Palavelli
 * Description: Making sure everything works
 * Due: 10/29/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class TransactionNGTest {
    
    static Transaction transaction;
    LocalDateTime date=LocalDateTime.now();
    public TransactionNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
        transaction=new Transaction("DEPOSIT", 450.0, date);
        transaction.setAdditionalCharges(8.39);
        transaction.setStatus("FAILED");
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
        transaction=null;
    }

    /**
     * Test of getAdditionalCharges method, of class Transaction.
     */
    @Test
    public void testGetAdditionalCharges() {
        System.out.println("getAdditionalCharges");
        double expResult = 8.39;
        double result = transaction.getAdditionalCharges();
        assertEquals(result, expResult);
    }

    /**
     * Fail test case method to test additional charges method of class Transaction.
     */
    @Test
    public void testGetAdditionalChargesFail() {
        
        double expResult = 12.39;
        double result = transaction.getAdditionalCharges();
        assertNotEquals(result, expResult);
    }
    
    /**
     * Test of setAdditionalCharges method, of class Transaction.
     */
    @Test
    public void testSetAdditionalCharges() {
        System.out.println("setAdditionalCharges");
        double additionalCharges = 100.0;

        transaction.setAdditionalCharges(additionalCharges);
        assertEquals(transaction.getAdditionalCharges(), additionalCharges);
    }
    
    /**
     * Fail test case method to test additional charges method of class Transaction.
     */
    @Test
    public void testSetAdditionalChargesFail() {
        System.out.println("setAdditionalCharges");
        double additionalCharges = 1560.0;

        transaction.setAdditionalCharges(additionalCharges);
        assertNotEquals(transaction.getAdditionalCharges(), 100.00);
    }

    
    /**
     * Test of getAmount method, of class Transaction.
     */
    @Test
    public void testGetAmount() {
        System.out.println("getAmount");
        double expResult = 450.0;
        double result = transaction.getAmount();
        assertEquals(result, expResult);
    }

    /**
     * Fail test case method to test get amount method of class Transaction.
     */
    @Test
    public void testGetAmountFail() {
        System.out.println("getAmount");
        //double noticedAmount = 1333.0;
        double gettingAmount = transaction.getAmount();
        assertNotEquals(gettingAmount, 100);
    }

    /**
     * Test of setAmount method, of class Transaction.
     */
    @Test
    public void testSetAmount() {
        double gettingAmount = 1000.0;
        transaction.setAmount(1000.0);

        assertEquals(gettingAmount, transaction.getAmount());
    }
    
    /**
     * Fail test case method to test set amount method of class Transaction.
     */
    @Test
    public void testSetAmountFail() {
        double gettingAmount = 1580.0;
        transaction.setAmount(1000.0);

        assertNotEquals(gettingAmount, transaction.getAmount());
    }
   
    /**
     * Test of getStatus method, of class Transaction.
     */
    @Test
    public void testGetStatus() {
        System.out.println("getStatus");
        String expResult = "FAILED";
        String result = transaction.getStatus();
        assertEquals(result, expResult);
    }

    /**
     * Fail test case method to test get status method of class Transaction.
     */
    @Test
    public void testGetStatusFail() {
        
        transaction.setStatus("SUCCESS");
        String gettingResult = transaction.getStatus();
        assertNotEquals("Failed", gettingResult);
    }

    /**
     * Test of setStatus method, of class Transaction.
     */
    @Test
    public void testSetStatus() {
        System.out.println("setStatus");  
        transaction.setStatus("SUCCESS");
        String result = transaction.getStatus();
        assertEquals(result, "SUCCESS");
    }
    
    /**
     * Fail test case method to test set status method of class Transaction.
     */
    @Test
    public void testSetStatusFail() {
        System.out.println("setStatus");      
        transaction.setStatus("Failed");
        String gettingResult = transaction.getStatus();
        assertNotEquals("SUCCESS", gettingResult);
    }

    /**
     * Test of getTransactionTime method, of class Transaction.
     */
    @Test
    public void testGetTransactionTime() {
        
        System.out.println("getTransactionTime");        
        LocalDateTime expResult = date;
        LocalDateTime result = transaction.getTransactionTime();
        assertEquals(result, expResult);
    }

    /**
     * Fail test case method to test get transaction method of class Transaction.
     */
    @Test
    public void testGetTransactionTimeFail() {
        LocalDateTime localTimeDt = transaction.getTransactionTime();
        assertNotEquals(LocalDateTime.MAX, localTimeDt);
    }

    /**
     * Test of setDateTime method, of class Transaction.
     */
    @Test
    public void testSetTransactionTime() {

        transaction.setTransactionTime(LocalDateTime.MIN);
        assertEquals(LocalDateTime.MIN, transaction.getTransactionTime());
    }
    
    /**
     * Fail test case method to test set transaction time method of class Transaction.
     */
    @Test
    public void testSetTransactionTimeFail() {

        transaction.setTransactionTime(LocalDateTime.MIN);
        assertNotEquals(LocalDateTime.MAX, transaction.getTransactionTime());
    }


    /**
     * Test of getTransactionType method, of class Transaction.
     */
    @Test
    public void testGetTransactionType() {
        System.out.println("getTransactionType");
        String expResult = "DEPOSIT";
        String result = transaction.getTransactionType();
        assertEquals(result, expResult);
    }

    /**
     * Fail test case method to test get transaction type method of class Transaction.
     */
    @Test
    public void testGetTransactionTypeFail() {
        
        String getting = transaction.getTransactionType();
        String noticed = "PURCHASE";
        assertNotEquals(noticed, getting);
    }

    /**
     * Test of setTransactionType method, of class Transaction.
     */
    @Test
    public void testSetTransactionType() {
        System.out.println("setTransactionType");
        String transType=  "DEPOSIT";
        transaction.setTransactionType(transType);
        assertEquals(transType, transaction.getTransactionType());
    }
    
    /**
     * Fail test case method to test set transaction type method of class Transaction.
     */
    @Test
    public void testSetTransactionTypeFail() {
        System.out.println("setTransactionType");
        String transType = "ONLINEPURCHASE";
        transaction.setTransactionType(transType);
        assertNotEquals("WITHDRAW", transaction.getTransactionType());
    }
    
    /**
     * Test of toString method, of class Transaction.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        
        String expectedResult = "DEPOSIT "+date+" 450.0 8.39 FAILED";
        String result = transaction.toString();
        assertEquals(result, expectedResult);
    }
    
}