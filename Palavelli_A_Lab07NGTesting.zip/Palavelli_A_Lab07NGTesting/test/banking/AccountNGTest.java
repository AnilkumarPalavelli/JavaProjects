/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.time.LocalDateTime;
import java.util.ArrayList;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Anilkumar Palavelli
 * Description: Making sure everything works
 * Due: 10/29/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class AccountNGTest {
    
    static Account account;
    static Customer customer;
    static Transaction transaction;
    static ArrayList<Transaction> transactions = new ArrayList<>();
    LocalDateTime date=LocalDateTime.now();
    
    /**
     * No argument constructor
     */
    public AccountNGTest() {
    }

    /**
     * setup class
     * @throws Exception 
     */
    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    /**
     * tear down method
     * @throws Exception 
     */
    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    /**
     * Setup method
     * @throws Exception 
     */
    @BeforeMethod
    public void setUpMethod() throws Exception {
        
        transaction = new Transaction("DEPOSIT", 5000.00, date);
        transactions.add(transaction);
        customer = new Customer("09/03/1997", "Anilkumar", "palavelli");
        account = new Account(875399860, customer, false);
    }

    /**
     * After method
     * @throws Exception 
     */
    @AfterMethod
    public void tearDownMethod() throws Exception {
        transaction=null;
        customer=null;
        account=null;
    }

    /**
     * Method to test getAccountNumber method of class Account.
     */
    @Test
    public void testGetAccountNumber() {
        System.out.println("getAccountNumber");
        long expectedResult = 875399860;
        long result = account.getAccountNumber();
        assertEquals(result, expectedResult);
    }
    /**
     * Fail test case method to test getAccountNumber method of class Account.
     */
    @Test
    public void testGetAccountNumberFail() {
        System.out.println("getAccountNumber");
        long expectedResult = 9182054;
        long result = account.getAccountNumber();
        assertNotEquals(result, expectedResult);
    }

    /**
     * Method to Test getCustomer method, of class Account.
     */
    @Test
    public void testGetCustomer() {
        System.out.println("getCustomer");
        Customer result = account.getCustomer();
        assertEquals(result, customer);
    }
    
    /**
     * Fail test case method to test customer method of class Account.
     */
    @Test
    public void testGetCustomerFail() {
        System.out.println("getCustomer");
        Customer result = account.getCustomer();
        assertNotEquals(result, null);
    }

    /**
     * Test of getBalance method, of class Account.
     */
    @Test
    public void testGetBalance() {
        System.out.println("getBalance");
        double result = account.getBalance();
        assertEquals(result, 0.00);
    }

    /**
     * Fail test case method to test balance method of class Account.
     */
    @Test
    public void testGetBalanceFail() {
        System.out.println("getBalance");

        double expect = 41.0;
        double actual = account.getBalance();
        assertNotEquals(actual, expect);
    }
    
    /**
     * Test of getTransactions method, of class Account.
     */
    @Test
    public void testGetTransactions() {
        System.out.println("getTransactions");
        ArrayList result = account.getTransactions();
        assertEquals(result.size(), 0);
    }

    /**
     * Fail test case method to test transactions method of class Account.
     */
    @Test
    public void testGetTransactionsFail() {
        System.out.println("getTransactions");
        ArrayList result = account.getTransactions();
        assertNotEquals(result.size(), 5);
    }
    
    /**
     * Test of isHasLimitedWithdrawals method, of class Account.
     */
    @Test
    public void testIsHasLimitedWithdrawals() {
        System.out.println("isHasLimitedWithdrawals");
        boolean expResult = false;
        boolean result = account.isHasLimitedWithdrawals();
        assertEquals(result, expResult);
    }

    /**
     * Fail test case method to test limited withdrawals method of class Account.
     */
    @Test
    public void testIsHasLimitedWithdrawalsFail() {
        System.out.println("isHasLimitedWithdrawals");
        boolean expect = true;
        boolean actual = account.isHasLimitedWithdrawals();
        assertNotEquals(actual, expect);

    }
    
 

    /**
     * Test of generateStatement method, of class Account.
     */
    @Test
    public void testGenerateStatement() {
        System.out.println("generateStatement");
        String result = account.generateStatement();
        assertTrue(!result.isEmpty());
    }

    /**
     * Fail test case method to test generate statement method of class Account.
     */
    @Test
    public void testGenerateStatementFail() {
        System.out.println("generateStatement");
        String result = account.generateStatement();
        assertFalse(result.isEmpty());
    }

    /**
     * Test of getNoofWithdrawals method, of class Account.
     */
    @Test
    public void testGetNoofWithdrawals() {
        System.out.println("getNoofWithdrawals");
        int expResult = 0;
        int result = account.getNoofWithdrawals();
        assertEquals(result, expResult);
    }

    /**
     * Fail test case method to test no of withdrawls method of class Account.
     */
    @Test
    public void testGetNoofWithdrawalsFail() {
        System.out.println("getNoofWithdrawals");
        int expected = 24;
        int actual = account.getNoofWithdrawals();
        assertNotEquals(actual, expected);
    }
    
    /**
     * Test of makeTransaction method, of class Account.
     */
    @Test
    public void testMakeTransaction() {
        System.out.println("makeTransaction");
        String expResult = "Transaction Successful";
        String result = account.makeTransaction(transaction);
        assertEquals(result, expResult);
    }
    
    /**
     * Fail test case method to test make transaction method of class Account.
     */
    @Test
    public void testMakeTransactionFail() {
        System.out.println("makeTransaction");
        String expectedResult = "Transaction Failed";
        String actualResult = account.makeTransaction(transaction);
        assertNotEquals(actualResult, expectedResult);    
    }
}