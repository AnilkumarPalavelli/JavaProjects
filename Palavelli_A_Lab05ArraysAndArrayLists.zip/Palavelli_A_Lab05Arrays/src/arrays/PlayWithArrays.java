/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrays;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Anilkumar_Palaveli_S549406
 */
public class PlayWithArrays {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String[] moviesA =new String[5];
        double[] doubleA =new double[6];
        int[] intA =new int[7];
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter the movies array elements :");
        for(int i=0;i<moviesA.length-1;i++){
            String s1=scan.nextLine();
            moviesA[i]=s1;
        }
        System.out.println("Enter the double array elements :");
        for(int j=0;j<doubleA.length-1;j++){
            double d1=scan.nextDouble();
            doubleA[j]=d1;
        }
        System.out.println("Enter the integer array elements :");
        for(int k=0;k<intA.length-1;k++){
            int i1=scan.nextInt();
            intA[k]=i1;
        }
        System.out.println("*****************TRAVERSE********************");
        System.out.println(Arrays.toString(moviesA));
        System.out.println(Arrays.toString(doubleA));
        System.out.println(Arrays.toString(intA));
        System.out.println("Array movies before insertion :");
        for(int i=0;i<moviesA.length;i++){
            System.out.print(moviesA[i]+" ");
        }
        System.out.println("\n"+"Array double elements before insertion");
        for(int j=0;j<doubleA.length;j++){
            System.out.print(doubleA[j]+" ");
        }
        System.out.println("\n"+"Array integer elements before insertion : ");
        for(int k=0;k<intA.length;k++){
            System.out.print(intA[k]+" ");
        }
        System.out.println("\n"+"*****************INSERTION********************");
        System.out.println("\n"+"movies array elements after insertion:");
        for(int i=moviesA.length-1;i>=3;i--){
            moviesA[i]=moviesA[i-1];
        
    }
        moviesA[2]="Avengers";
        for(int i=0;i<moviesA.length;i++){
            System.out.print(moviesA[i]+" ");
        }
        System.out.println("\n"+"doubleArray elements after insertion:");
        for(int j=doubleA.length-1;j>=3;j--){
            doubleA[j]=doubleA[j-1];
        }
        doubleA[2]=20.89;
        for(int j=0;j<doubleA.length;j++){
            System.out.print(doubleA[j]+" ");
        }
        System.out.println("\n"+"intArray elements after insertion:");
        for(int k=intA.length-1;k>=3;k--){
            intA[k]=intA[k-1];
        }
        intA[2]=369;
        for(int k=0;k<doubleA.length;k++){
            System.out.print(doubleA[k]+" ");
        }
        System.out.println("\n"+"*****************DELETION********************");
        System.out.println("\n"+"Array movies elements after deleting:");
        for(int i=2;i<moviesA.length;i++){
            moviesA[i-1]=moviesA[i];
        }
        for(int i=0;i<moviesA.length-1;i++){
            System.out.print(moviesA[i]+" ");
       
        }
        System.out.println("\n"+"doubleArray elements after deleting:");
        for(int j=2;j<doubleA.length;j++){
            doubleA[j-1]=doubleA[j];
        }
        for(int j=0;j<doubleA.length-1;j++){
            System.out.print(doubleA[j]+" ");
        }
        System.out.println("\n"+"intArray elements after deleting:");
        for(int k=2;k<intA.length;k++){
            intA[k-1]=intA[k];
        }
        for(int k=0;k<intA.length-1;k++){
            System.out.print(intA[k]+" ");
        }
        System.out.println("\n"+"*****************SEARCH********************");
        for(int i=0;i<moviesA.length;i++){
            if(moviesA[i].equals("Avengers")){
                System.out.println("Element Avengers Found at index" +i+" of movies");
                
            }
        }
        for(int j=0;j<doubleA.length;j++){
            if(doubleA[j]==(20.89)){
                System.out.println("Element 20.89 Found at index "+j+" of doubleArray");
                
            }
        }
        for(int k=0;k<intA.length;k++){
            if(intA[k]==(369)){
                System.out.println("Element 369 Found at index "+k+" of intArray");
            }
        }
        System.out.println("\n"+"*****************UPDATE********************");
        System.out.println("movies after updating:");
          for(int i=0;i<moviesA.length;i++){
            if(moviesA[i].equals("Avengers")){
                moviesA[i]="WonderWoman";
            }
        }
          
         for(int i=0;i<moviesA.length-1;i++){
             System.out.print(moviesA[i]+" ");
        }
        
         System.out.println("\ndoubleArray elements after updating: ");
          for(int j=0;j<doubleA.length;j++){
            if(doubleA[j]==20.89){
                doubleA[j]=67.45;
            }
        }
          
         for(int j=0;j<doubleA.length-1;j++){
             System.out.print(doubleA[j]+" ");
        }
        
          System.out.println("\nintArray elements after updating: ");
          for(int k=0;k<intA.length;k++){
            if(intA[k]==369){
                intA[k]=729;
            }
        }
          
         for(int k=0;k<intA.length-1;k++){
             System.out.print(intA[k]+" ");
        }
         System.out.println("");
        
    }
    
}
        
        
        
        // TODO code application logic here
    
    

