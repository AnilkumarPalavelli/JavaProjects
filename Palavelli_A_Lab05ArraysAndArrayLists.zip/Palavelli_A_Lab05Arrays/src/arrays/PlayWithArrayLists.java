/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrays;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Anilkumar_Palavelli_S549406
 */
public class PlayWithArrayLists {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<String>moviesAL=new ArrayList<String>(4);
        ArrayList<Double>doubleAL=new ArrayList<Double>(5);
        ArrayList<Integer>intAL=new ArrayList<Integer>(6);
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter the movie names : ");
        for(int i=0;i<4;i++){
            moviesAL.add(scan.nextLine());
        }
        System.out.println("Enter the double elements: ");
        for(int j=0;j<5;j++){
            doubleAL.add(scan.nextDouble());
            
        }
        System.out.println("Enter the integers: ");
        for(int k=0;k<6;k++){
            intAL.add(scan.nextInt());
            
        }
        System.out.println("*****************TRAVERSE********************");
        System.out.println(moviesAL);
        System.out.println(doubleAL);
        System.out.println(intAL);
        
        System.out.println("*****************INSERTION********************");
        
        moviesAL.add(2,"Avengers");
        doubleAL.add(2,20.89);
        intAL.add(2,369);
        
        System.out.println(moviesAL);
        System.out.println(doubleAL);
        System.out.println(intAL);
        
        System.out.println("*****************DELETION********************");
        moviesAL.remove(1);
        doubleAL.remove(1);
        intAL.remove(1);
        
        System.out.println(moviesAL);
        System.out.println(doubleAL);
        System.out.println(intAL);
        
        System.out.println("*****************SEARCH********************");
        System.out.println("Index of Avengers element in moviesAL is "+moviesAL.indexOf("Avengers"));
        System.out.println("Index of 20.89 element in doubleAL is "+doubleAL.indexOf(20.89));
        System.out.println("Index of 369 element in intAL is "+intAL.indexOf(369));
        
        System.out.println(moviesAL);
        System.out.println(doubleAL);
        System.out.println(intAL);
        
        System.out.println("*****************UPDATION********************");
        moviesAL.set(moviesAL.indexOf("Avengers"),"WonderWoman");
        doubleAL.set(doubleAL.indexOf(20.89),67.45);
        intAL.set(intAL.indexOf(369),729);     
        
        System.out.println(moviesAL);
        System.out.println(doubleAL);
        System.out.println(intAL);
                
    }
    
}
        
        
   
    
