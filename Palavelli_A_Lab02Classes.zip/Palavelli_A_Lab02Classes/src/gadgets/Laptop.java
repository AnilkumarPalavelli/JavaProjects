
package gadgets;

/**
 *this class helps in setting and getting attributes of Laptop
 * @author Anilkumar Palavelli_S549406
 */
public class Laptop {
    private String brand;
    private String processor;
    private String osName;
    private int memorySize;
    private double screenSize;
    private boolean touch;
/**
 * one constructor with six parameters
 * @param brand
 * @param processor
 * @param osName
 * @param memorySize
 * @param screenSize
 * @param touch 
 */
    public Laptop(String brand, String processor, String osName, int memorySize, double screenSize, boolean touch) {
        this.brand = brand;
        this.processor = processor;
        this.osName = osName;
        this.memorySize = memorySize;
        this.screenSize = screenSize;
        this.touch = touch;
    }
/**
 * no-argument constructor
 */
    public Laptop() {
    }
    
/**
 * getter method returns the Laptop brand 
 * @return String brand
 */
    public String getBrand() {
        return brand;
    }
/**
 * getter method returns the Name of the processor
 * @return String processor
 */
    public String getProcessor() {
        return processor;
    }
/**
 * getter method returns the operation system name
 * @return String osName
 */
    public String getOsName() {
        return osName;
    }
/**
 * getter method returns the Hard drive capacity in GB's
 * @return int memorySize
 */
    public int getMemorySize() {
        return memorySize;
    }
/**
 * getter method returns screenSize
 * @return double screenSize
 */
    public double getScreenSize() {
        return screenSize;
    }
/**
 * getter methods returns touch
 * @return boolean touch
 */
    public boolean isTouch() {
        return touch;
    }
/**
 * setter method sets the new laptop brand
 * @param brand 
 */
    public void setBrand(String brand) {
        this.brand = brand;
    }
/**
 * setter method sets the new Name of the processor
 * @param processor 
 */
    public void setProcessor(String processor) {
        this.processor = processor;
    }
/**
 * setter method sets the new operation system name
 * @param osName 
 */
    public void setOsName(String osName) {
        this.osName = osName;
    }
/**
 * setter method sets the new hard drive capacity in GB's
 * @param memorySize 
 */
    public void setMemorySize(int memorySize) {
        this.memorySize = memorySize;
    }
/**
 * setter method sets new size of the screen
 * @param screenSize 
 */
    public void setScreenSize(double screenSize) {
        this.screenSize = screenSize;
    }
/**
 * setter method sets touch
 * @param touch 
 */
    public void setTouch(boolean touch) {
        this.touch = touch;
    }
    
/**
 * toString() method  is used to return all the Laptop instance values
 * @return Written String  type concatenation of instance variables
 */
    @Override
    public String toString() {
        return  "Laptop brand:" + brand +"\n"+ " Laptop processor:" + processor +"\n"+ " Laptop osName:" + osName +"\n"+ " Laptop Hard Drive:" + memorySize +"\n" +" Laptop Display:" + screenSize +"\n"+ " Laptop Is Touch: " + touch ;
    }
}
    
    

    

    

    

    

    
    
    

