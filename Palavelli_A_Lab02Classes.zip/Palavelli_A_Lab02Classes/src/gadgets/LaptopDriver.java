package gadgets;

/**
 *This class is driver class of laptop class
 * @author Anilkumar Palavelli_S549406
 */
public class LaptopDriver {

    /**
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Laptop obj1Laptop=new Laptop("HP","Intel Core i5","windows",512,12.4,true);
        System.out.println("*Testing getter method on obj1Laptop *");
        System.out.println("Laptop Brandis:" +obj1Laptop.getBrand());
        System.out.println("Name of the processor is:" +obj1Laptop.getProcessor());
        System.out.println("Operating System name:" +obj1Laptop.getOsName());
        System.out.println("Hard Drive capacity in GB's:" +obj1Laptop.getMemorySize());
        System.out.println("Screen Size:" +obj1Laptop.getScreenSize());
        System.out.println("is Touch:" +obj1Laptop.isTouch());
        System.out.println("*Testing toString method on obj1Laptop*");
        System.out.println(obj1Laptop);
        Laptop obj2Laptop=new Laptop();
        //created new obj2 named obj2Laptop
        System.out.println("*Testing toString method on obj2Laptop*");
        System.out.println(obj2Laptop);
        obj2Laptop.setBrand("Apple");
        obj2Laptop.setProcessor("Intel core i3");
        obj2Laptop.setOsName("macOS Mojave");
        obj2Laptop.setMemorySize(256);
        obj2Laptop.setScreenSize(10.5);
        obj2Laptop.setTouch(false);
        System.out.println("Testing toString method on obj2Laptop*");
        System.out.println(obj2Laptop);
        System.out.println("*Testing getter method on obj2Laptop *");
        System.out.println("Laptop Brandis:" +obj2Laptop.getBrand());
        System.out.println("Name of the processor is:" +obj2Laptop.getProcessor());
        System.out.println("Operating System name:" +obj2Laptop.getOsName());
        System.out.println("Hard Drive capacity in GB's:" +obj2Laptop.getMemorySize());
        System.out.println("Screen Size:" +obj2Laptop.getScreenSize());
        System.out.println("is Touch:" +obj2Laptop.isTouch());
        
         
   }
  
    }
    

