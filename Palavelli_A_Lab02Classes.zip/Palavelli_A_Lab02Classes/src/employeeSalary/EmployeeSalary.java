
package employeeSalary;

/**
 *This class object helps in setting and getting different attributes of employee
 * @author Anilkumar Palavelli_S549406
 * 
 */
public class EmployeeSalary {
    private double wagePerHour;
    private double insurancePercentage;
    private double taxPercentage;
    private double pfPercentage;
    private static final int HOURS=40;
/**
 * Creating one constructor with four parameters with wagePerhour,insurancePercentage,taxPercentage,pfPercentage
 * @param wagePerHour
 * @param insurancePercentage
 * @param taxPercentage
 * @param pfPercentage 
 */
    public EmployeeSalary(double wagePerHour, double insurancePercentage, double taxPercentage, double pfPercentage) {
        this.wagePerHour = wagePerHour;
        this.insurancePercentage = insurancePercentage;
        this.taxPercentage = taxPercentage;
        this.pfPercentage = pfPercentage;
    }

   /**
    * no-argument constructor 
    */
    public EmployeeSalary() {
    }
/**
 * getter method returns the wage per hour of the employee 
 * @return wagePerHour 
 */
    public double getWagePerHour() {
        return wagePerHour;
    }
/**
 * getter method returns the insurance percentage of the employee
 * @return double insurancePercentage 
 */
    public double getInsurancePercentage() {
        return insurancePercentage;
    }
/**
 * getter method returns the tax percentage of the employee
 * @return double taxPercentage
 */
    public double getTaxPercentage() {
        return taxPercentage;
    }
/**
 * getter method returns the pf percentage of the employee
 * @return double pfPercentage
 */
    public double getPfPercentage() {
        return pfPercentage;
    }

    
/**
 * setter method sets the wage per hour of the employee
 * @param wagePerHour 
 */
    public void setWagePerHour(double wagePerHour) {
        this.wagePerHour = wagePerHour;
    }
/**
 * setter method sets the insurance percentage of the employee
 * @param insurancePercentage 
 */
    public void setInsurancePercentage(double insurancePercentage) {
        this.insurancePercentage = insurancePercentage;
    }
/**
 * setter method sets the tax percentage of the employee
 * @param taxPercentage 
 */
    public void setTaxPercentage(double taxPercentage) {
        this.taxPercentage = taxPercentage;
    }
/**
 * setter method sets the pf percentage of the employee
 * @param pfPercentage 
 */
    public void setPfPercentage(Double pfPercentage) {
        this.pfPercentage = pfPercentage;
    }
  /**
   *In this method returns calculating monthly salary of the employee
   * @return MonthlySalary
   */  
    public double calcMonthlySalary(){
        double MonthlySalary= wagePerHour*HOURS*4;
        return MonthlySalary;
    }
    /**
     *In this method returns Calculating monthly insurance 
     * @return MonthlyInsurance
     */
    public double calcMonthlyInsurance(){
        double MonthlyInsurance = wagePerHour*HOURS*4*(insurancePercentage)/100;
        return MonthlyInsurance;
    }
    /**
     *In this method returns Calculating monthly pf amount of employee 
     * @return MonthlyPfAmount
     */
    public double calcMonthlyPfAmount(){
        double MonthlyPfAmount= wagePerHour*HOURS*4*(pfPercentage)/100;
        return MonthlyPfAmount;
    }
    /**
     *In this method returns Calculating AnnualGrossSalary of the employee
     * @param bonus
     * @return AnnualGrossSalary
     */
    public double calcAnnualGrossSalary(double bonus){
        double AnnualGrossSalary=bonus + (wagePerHour*HOURS*4*12);
        return AnnualGrossSalary;
    }
    /**
     * In this method returns calculating annual net pay of the employee 
     * @param bonus
     * @return AnnulaNetPay 
     */
    public double calcAnnualNetPay(double bonus){
        double annualNetPay=calcAnnualGrossSalary(bonus)-(calcAnnualGrossSalary(bonus)*taxPercentage/100)-calcMonthlyInsurance()*12-calcMonthlyPfAmount()*12;  
        return annualNetPay;
    }
/**
 * to String method returns the all instances of the employee
 * @return written String type and concatenation of instance variables
 */
    @Override
    public String toString() {
        return  "wagePerHour:" + wagePerHour + ", insurancePercentage:" + insurancePercentage + ", taxPercentage:" + taxPercentage + ", pfPercentage:" + pfPercentage + ", HOURS:" + HOURS ;
    }
    
        
    }
    

    

 
    
    
    

