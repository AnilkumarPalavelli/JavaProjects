package objects;
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S549406
 */
public class StringsAndNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String s1="  Welcome     to   the first    Lab Activity  in the    OOP Course ";
        System.out.println(s1);
        System.out.println("The length of the string is:"+s1.length());
        
        
        String L1=s1.substring(2,9).toUpperCase();
        System.out.println(L1);
        String L2=s1.substring(14,16).toUpperCase();
        System.out.println(L2);
        String L3=s1.substring(19,28).toUpperCase();
        System.out.println(L3);
        String L4=s1.substring(32,45).toUpperCase();
        System.out.println(L4);
        String L5=s1.substring(46,54).toUpperCase();
        System.out.println(L5);
        String L6=s1.substring(56,66).toUpperCase();
        System.out.println(L6);
        
        String s2="lab-interesting-activities-are-activities-lab-Interesting-Lab-Activities-Are Interesting Lab activities Lab Interesting";
        System.out.println(s2);
        System.out.println("The first occurrence of the word Interesting is :"+s2.indexOf("Interesting"));
        s2=s2.replaceAll("-","_");
        s2=s2.replaceAll(" ","-");
        System.out.println(s2);
        
        System.out.println("I choose Applied Computer Science because, I want to become a good software Developer and also it would be helpful for my career opportunities. ");
        
        System.out.println("sqrt (10^2+14^2): "+Math.sqrt(10*10+14*14));
        System.out.println("tan 60° - tan 45° / (1 + tan 60° tan 45°) ="+Math.tan(15));
        System.out.println("Rounded Value of cos 45: "+Math.round(Math.cos(45)));
        System.out.println("Rounded Value of cos 27: "+Math.round(Math.cos(27)));
        System.out.println("Rounded Value of tan 45: "+Math.round(Math.tan(45)));
        System.out.println("Rounded Value of tan 27: "+Math.round(Math.tan(27)));
        System.out.println("The value of given equation is :"+Math.abs(8*Math.cos(27))*(Math.pow(Math.pow(7, 4)+8*6*7*5, 0.25))/Math.pow((5*5-3*3), 0.125));
        
        Random rnd = new Random();
        int a=rnd.nextInt(500);
        System.out.print("First random integer value is: "+a);
        System.out.println(" Square of a is:"+Math.pow(a, 2));
        int b=rnd.nextInt(500);
        System.out.print("Second random integer value is: "+b);
        System.out.println(" Square of b is:"+Math.pow(b, 2));
        int c=rnd.nextInt(500);
        System.out.print("Third random integer value is: "+c);
        System.out.println(" Square of c is:"+Math.pow(c, 2));
        int d=rnd.nextInt(500);
        System.out.print("Fourth random integer value is: "+d);
        System.out.println(" Square of d is:"+Math.pow(d, 2));
        int e=rnd.nextInt();
        System.out.println("Fifth rafthndom integer value is: "+e);
        int f=rnd.nextInt();
        System.out.println("Sixth random integer value is: "+f);
        int g=rnd.nextInt();
        System.out.println("Seventh random integer value is: "+g);
        System.out.println("No I didnot get the same results ,Results are changing randomly");
        Random r1 = new Random(20);
        int h=r1.nextInt(500);
        System.out.print("First random integer value is: "+h);
        System.out.println(" Square of h is:"+Math.pow(h, 2));
        int i=r1.nextInt(500);
        System.out.print("Second random integer value is: "+i);
        System.out.println(" Square of i is:"+Math.pow(i, 2));
        int j=r1.nextInt(500);
        System.out.print("Third random integer value is: "+j);
        System.out.println(" Square of j is:"+Math.pow(j, 2));
        int k=r1.nextInt(500);
        System.out.print("Fourth random integer value is: "+k);
        System.out.println(" Square of k is:"+Math.pow(k, 2));
        int l=r1.nextInt();
        System.out.println("Fifth rafthndom integer value is: "+l);
        int m=r1.nextInt();
        System.out.println("Sixth random integer value is: "+m);
        int n=r1.nextInt();
        System.out.println("Seventh random integer value is: "+n);
        System.out.println("Yes I got the same results after executing three times");
        System.out.println("The results in b altering every time with no seed value but in the d we have seed value so it is not changing");
    
        
        
        // TODO code application logic here
    }
    
}
