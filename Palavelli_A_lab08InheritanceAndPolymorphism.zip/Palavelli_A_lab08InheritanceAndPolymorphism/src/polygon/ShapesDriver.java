/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Anilkumar Palavelli
 * Description: Making sure everything works
 * Due: 11/08/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class ShapesDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        ArrayList<Polygon>polygonList=new ArrayList<Polygon>();
        /**
         * read the values from the file
         */
        Scanner pols=new Scanner(new File("shapes.txt"));
        while (pols.hasNext()) {
            String input = pols.nextLine();
            String input1[] = input.split(" ");
            switch (input1[0]) {
                case "cube":
                    polygonList.add(new Cube(Double.parseDouble(input1[1])));
                    break;
                case "pentagon":
                    String pName = input1[0].substring(0, 1).toUpperCase() + input1[0].substring(1);
                    polygonList.add(new RegularPolygon(pName, Integer.parseInt(input1[1]), Double.parseDouble(input1[2])));
                    break;
                case "tetrahedron":
                    polygonList.add(new Tetrahedron(Double.parseDouble(input1[1])));
                    break;
                case "triangle":
                    polygonList.add(new EquilateralTriangle(Double.parseDouble(input1[1])));
                    break;
                case "square":
                    polygonList.add(new Square(Double.parseDouble(input1[1])));
                    break;
                default:
                    String pName1 = input1[0].substring(0, 1).toUpperCase() + input1[0].substring(1);
                    polygonList.add(new RegularPolygon(pName1, Integer.parseInt(input1[1]), Double.parseDouble(input1[2])));
            }
        }
        double largestArea = 0.0;
        double smallestArea = Double.MAX_VALUE;
        double largestPerimetter = 0.0;
        double smallestPerimetter = Double.MAX_VALUE;
        String largestareaPolygon = null;
        String smallestareaPolygon = null;
        String largestperimeterpolygon = null;
        String smallestperimeterpolygon = null;
        /**
         * Creating an enhanced for loop and print all the Polygon’s in the arrayList  
         */
         for (Polygon polygons : polygonList) {
             System.out.println("*****************************************");
             System.out.println(polygons.toString());
             if (polygons.getArea() > largestArea) {
                largestArea = polygons.getArea();
                largestareaPolygon = polygons.getName();
            }
             if (polygons.getArea() < smallestArea) {
                smallestArea = polygons.getArea();
                smallestareaPolygon = polygons.getName();
            }
             if (polygons.getPerimeter() > largestPerimetter) {
                largestPerimetter = polygons.getPerimeter();
                largestperimeterpolygon = polygons.getName();
            }
              if (polygons.getPerimeter() < smallestPerimetter) {
                smallestPerimetter = polygons.getPerimeter();
                smallestperimeterpolygon = polygons.getName();
            }

         }
         System.out.println("****");
        System.out.println("The polygon with largest area is " + largestareaPolygon + " with area of " + String.format("%.2f", largestArea) + "cm\u00b2");
        System.out.println("The polygon with smallest area is " + smallestareaPolygon + " with area of " + String.format("%.2f", smallestArea) + "cm\u00b2");
        System.out.println("The polygon with largest perimeter is " + largestperimeterpolygon + " with perimeter of " + largestPerimetter + "cms");
        System.out.println("The polygon with smallest perimeter is " + smallestperimeterpolygon + " with perimeter of " + smallestPerimetter + "cms");
        System.out.println("****");
        System.out.println("Surface area to Volume ratio of given solids are:");
        for (Polygon polygonn : polygonList) {
            if (polygonn instanceof Cube) {
                System.out.println("Cube:\n" + "	Surface area: " + String.format("%.2f", polygonn.getArea()) + "cm\u00b2"
                        + "\n	Volume: " + String.format("%.2f", ((Cube) polygonn).getVolume()) + "cm\u00b3");
            } else if (polygonn instanceof Tetrahedron) {
                System.out.println("Tetrahedron:\n" + "	Surface area: " + String.format("%.2f", polygonn.getArea()) + "cm\u00b2"
                        + "\n	Volume: " + String.format("%.2f", ((Tetrahedron) polygonn).getVolume()) + "cm\u00b3");
            }

        }
        System.out.println("******************************************");
        System.out.println("At Line 86 where we are calling Cube class method using  the object that is stored in polygon reference variable."
                + " Also at lines 60,61,64,65,69,70,73,74,91 we implemented late binding polymorphism.");
        System.out.println("******************************************");
        System.out.println("At Line 35, where we stored Cube object in polygon reference variable and also at lines 38,39,40,41,44");
        System.out.println("******************************************");
    }
    
}
