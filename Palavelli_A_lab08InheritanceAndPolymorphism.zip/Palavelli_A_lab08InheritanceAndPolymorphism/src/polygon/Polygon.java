/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

/**
 *
 * @author S549406
 */
public class Polygon {

    private String name;
    private int nosides;

    /**
     * Constructor with two parameters
     *
     * @param name
     * @param nosides
     */
    public Polygon(String name, int nosides) {
        this.name = name;
        this.nosides = nosides;
    }

    /**
     * Getter method returns the name
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * getter method returns the number of sides
     *
     * @return noSides
     */
    public int getNosides() {
        return nosides;
    }

    /**
     * getter method returns the area
     *
     * @return Area
     */
    public double getArea() {
        return 0.0;

    }

    /**
     * Getter method returns the Perimeter
     *
     * @return Perimeter
     */
    public double getPerimeter() {
        return 0.0;
    }

    /**
     * Getter method returns the InternalTriangle
     *
     * @return InternalTriangle
     */
    public double getInternalAngle() {
        return 0.0;
    }

    /**
     * toString method returns the name and number of sides
     *
     * @return
     */
    @Override
    public String toString() {
        return "Polygon: " + getName()+ "\n        Number of Sides: " +getNosides();
    }

}
