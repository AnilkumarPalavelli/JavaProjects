/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

import enums.Solids;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Anilkumar Palavelli
 * Description: Making sure everything works
 * Due: 11/08/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Tetrahedron extends EquilateralTriangle {

    public Tetrahedron(double length) {
        super("Tetrahedron", length);
    }
 /**
  * Overrides the getHeight method and returns the height
  * @return  height
  */   
    @Override
    public double getHeight(){
        return (Math.sqrt(6)/3)*getLength();
    }
/**
 * Overrides the getArea and returns the Area
 * @return Area
 */
    @Override
    public double getArea() {
        return super.getArea()*Solids.TETRAHEDRON.getNofaces();
    }
/**
 * getVolume method returns the volume
 * @return volume
 */
    public double getVolume() {
        return (Math.sqrt(2)/12)*Math.pow(getLength(), 3);
    }
/**
 * getInsphereRadius method returns the inSphereRadius
 * @return inSphereRadius
 */
    public double getInSphereRadius() {
        return getLength()/Math.sqrt(24);
    }
/**
 * getCircumSphereRadius method returns the circumsphereRadius
 * @return circumsphereRadius
 */
    public double getCircumSphereRadius() {
        return (Math.sqrt(6) / 4) *getLength();
    }
/**
 * toString() method
 * @return 
 */
    @Override
    public String toString(){
        return super.toString()
                +"\n        Insphere radius: "+getInSphereRadius()+"cms\n" +
                "        Circumsphere radius:"+getCircumSphereRadius()+"cms\n" +
                "	Volume: "+getVolume()+"cm \u00b3";
    }

}
