/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Anilkumar Palavelli
 * Description: Making sure everything works
 * Due: 11/08/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class RegularPolygon extends Polygon {

    private double length;
/**
 * 
 * @param name
 * @param nosides
 * @param length 
 */
    public RegularPolygon(String name, int nosides, double length) {
        super(name, nosides);
        this.length = length;
    }
/**
 * getter method returns the length
 * @return length
 */
    public double getLength() {
        return length;
    }
/**
 * Overrides the getArea method returns the area 
 * @return area
 */
    @Override
    public double getArea() {
        double area = 0.25 * super.getNosides() * getLength() * getLength() * 1 / Math.tan(Math.PI / super.getNosides());
        return area;
    }
/**
 * Overrides the getPerimeter method returns the Perimeter
 * @return Perimeter 
 */
    @Override
    public double getPerimeter() {
        double perimeter = super.getNosides() * length;
        return perimeter;
    }
/**
 * getInternalAngle method returns the internalAngle
 * @return internalAngle
 */
    public double getInternalAngle() {
        double internalangle = 180.0 / super.getNosides() * (super.getNosides() - 2);
        return internalangle;
    }
/**
 * getInCircleRadius method returns the inCircleradius 
 * @return incircleRadius
 */
    public double getInCircleRadius() {
        double incircleradius = length / 2 * (1 / Math.tan(Math.PI / super.getNosides()));
        return incircleradius;
    }
/**
 * getCircumCircleRadius method returns the circumcircleRadius
 * @return circumcircleRadius
 */
    public double getCircumCircleRadius() {
        double circumcircleradius = length / 2 * (1 / Math.sin(Math.PI / super.getNosides()));
        return circumcircleradius;
    }
/**
 * toString method
 * @return 
 */
    @Override
    public String toString() {
        return super.toString()
                + "\n        Length of side: " + length + "cms"
                + "\n        Internal angle: " + getInternalAngle() + "\u00b0"
                + "\n        Circumcircle radius: " + getCircumCircleRadius() + "cms"
                + "\n        Incircle radius: "+getInCircleRadius()+"cms"
                + "\n        Area: " + getArea() + "cms" + "\u00b2"
                + "\n        Perimeter: " + getPerimeter() + "cms";
    }

}
