/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

import enums.Solids;

/**
 *
 * @author S549406
 */
public class Cube extends Square {

    public Cube(double length) {
        super("Cube", length);
    }

    @Override
    public double getArea() {
        double area = super.getArea() * Solids.CUBE.getNofaces();
        return area;
    }

    public double getVolume() {
        double volume = super.getLength() * super.getLength() * super.getLength();
        return volume;
    }

    public double getInSphereRadius() {
        double insphereradius = super.getLength() / 2;
        return insphereradius;
    }

    public double getCircumSphereRadius() {
        double circumsphereradius = Math.sqrt(3.0) / 2 * super.getLength();
        return circumsphereradius;
    }

    @Override
    public String toString() {
        return super.toString()
               +"\n	Insphere radius: "+String.format("%.2f",getInSphereRadius())+"cms"
               +"\n	Circumsphere radius: "+String.format("%.2f",getCircumSphereRadius())+"cms"
               +"\n	Volume: "+String.format("%.2f",getVolume())+"cm\u00b3";
    }

}
