/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

/**
 * Class: 44542-04 Object Oriented Programming
 * @author Anilkumar Palavelli
 * Description: Making sure everything works
 * Due: 11/08/22
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class EquilateralTriangle extends RegularPolygon {

    public EquilateralTriangle(double length) {
        super("Equilateral Triangle", 3, length);
    }

    public EquilateralTriangle(String name, double length) {
        super(name, 3, length);
    }
/**
 * getHeight method returns the Height
 * @return height
 */
    public double getHeight() {
        return Math.sqrt(3.0) / 2 * super.getLength();
    }
/**
 * toString() method returns height
 * @return Height
 */
    @Override
    public String toString() {
        return super.toString()+" \n        Height: "+getHeight()+"cms";

    }

}
