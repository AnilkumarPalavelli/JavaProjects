/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

import java.util.ArrayList;

/**
 *
 * @author S549406
 */
public abstract class Account {
    public long accountNumber;
    public double balance;
    public Customer customer;
    public ArrayList<Transaction> transactions;
/**
 * Constructor with two parameters
 * @param customer
 * @param accountNumber 
 */
    public Account(Customer customer,long accountNumber) {
        this.customer = customer;
        this.accountNumber = accountNumber;
        this.balance = 0.0;
        this.transactions = new ArrayList<Transaction>();
    }
/**
 * getter method to get the Account number 
 * @return account number
 */
    public long getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public Customer getCustomer() {
        return customer;
    }

    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }
    
    public String generateStatement() {
        String tranData = "";
        for (int i = 0; i < transactions.size(); i++) {
            tranData = tranData + transactions.get(i).toString() + "\n";
        }
         return toString()+ "\n-------------------------------------------------------------------------------\n"
                + "Transaction Type    Transaction Time         Amount          Additional Charges       Status    \n"
                + tranData
                + "-------------------------------------------------------------------------------\n";
    }
    
    public abstract double makeTransaction(Transaction transaction)throws Exception;
    

    @Override
    public String toString() {
        return customer.toString() + "\nAccount Number: " + accountNumber;
    }
    
    
    
}
