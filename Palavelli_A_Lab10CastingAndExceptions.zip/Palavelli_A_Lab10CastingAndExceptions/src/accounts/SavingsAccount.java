/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

import enums.TransactionType;
import exceptions.InsufficentFundsException;
import interfaces.Operations;
import java.text.DecimalFormat;
import java.time.LocalDateTime;

/**
 *
 * @author S549406
 */
public class SavingsAccount extends Account {
    public boolean hasLimitedWithdrawals;
    DecimalFormat dformt = new DecimalFormat("###.00");
    
    public SavingsAccount(Customer customer, long accountNumber, boolean hasLimitedWithdrawals){
        super(customer, accountNumber);
        this.hasLimitedWithdrawals=hasLimitedWithdrawals;
    }
    
     public String generateStatement(){
       return super.generateStatement()+"Current Balance: "+dformt.format(super.getBalance())+"   Interest: $"+dformt.format(super.getBalance()*(Operations.SAVING_INTEREST)/100)
               +"\n***************************";
        
    }
     
     public int getNoofWithdrawals(){
        int moneywithdraw = 0;
        for (int i = 0; i < transactions.size(); i++) {
            if (transactions.get(i).getTransactionType().equals(TransactionType.WITHDRAW) && (transactions.get(i).getTransactonTime().getMonth() == LocalDateTime.now().getMonth())) {
                moneywithdraw++;
            }
        }
        return moneywithdraw;
    }
     @Override
    public double makeTransaction(Transaction transaction) throws Exception{
        double availbal = super.getBalance() ;
        if(transaction.getTransactionType().equals(TransactionType.WITHDRAW)||transaction.getTransactionType().equals(TransactionType.ONLINEPURCHASE)){
        if(availbal<transaction.getAmount()){
           transaction.setAdditionalCharges(0.0);
           transaction.setStatus("FAILED");
           transactions.add(transaction);
           throw new InsufficentFundsException();  
        }      
    }
        if(availbal>transaction.getAmount()&&!hasLimitedWithdrawals&&transaction.getTransactionType().equals(TransactionType.WITHDRAW)){
            if(getNoofWithdrawals()>6){
                if (transaction.getAmount() * 0.01 > 2.59) {
                        transaction.setAdditionalCharges(transaction.getAmount() * 0.01);
                    } else {
                        transaction.setAdditionalCharges(2.59);
                    }
                transaction.setStatus("SUCCESS");
                transactions.add(transaction);
                balance=balance-(transaction.getAmount()+transaction.getAdditionalCharges());
                return balance;
                
            }
            else{
                transaction.setAdditionalCharges(0.0);
                transaction.setStatus("SUCCESS");
                transactions.add(transaction);
                balance=balance-(transaction.getAmount());
                return balance;
            } 
        }
        else if(availbal>transaction.getAmount()&&hasLimitedWithdrawals&&transaction.getTransactionType().equals(TransactionType.WITHDRAW)){
             if(getNoofWithdrawals()>6){
                 transaction.setAdditionalCharges(0.0);
                 transaction.setStatus("FAILED");
                 transactions.add(transaction);
                 balance=balance;
                 return balance;
             }
             else{
                 transaction.setAdditionalCharges(0.0);
                 transaction.setStatus("SUCCESS");
                 transactions.add(transaction);
                 balance=balance-(transaction.getAmount());
                 return balance;
             }
        }
        if((transaction.getTransactionType().equals(TransactionType.DEPOSIT)||transaction.getTransactionType().equals(TransactionType.ONLINEPURCHASE))){
            if(transaction.getTransactionType().equals(TransactionType.DEPOSIT)){
                transaction.setAdditionalCharges(0.0);
                 transaction.setStatus("SUCCESS");
                 transactions.add(transaction);
                 balance=balance+transaction.getAmount();
                 return balance;
            }
             if(transaction.getTransactionType().equals(TransactionType.ONLINEPURCHASE)){
                transaction.setAdditionalCharges(1.99);
                 transaction.setStatus("SUCCESS");
                 transactions.add(transaction);
                 balance=balance-transaction.getAmount()-transaction.getAdditionalCharges();
                 return balance;
            }
        }
        
        return 0.0;
    }
    public String toString(){
        String limit="No Limit";
        if(hasLimitedWithdrawals){
            limit="6 Transactions";
        }
        return super.toString()+"\n Account Type: Savings Account Interest Rate: "+dformt.format(Operations.SAVING_INTEREST)+"%\n Transaction Limit for withdrawal: "+limit;
        
     

    
    }
    
    
    
    
    
}
