/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

import enums.TransactionType;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author S549406
 */
public class BankDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws FileNotFoundException {
        
        // 1. Create an arraylist of Accounts and details it as accounts to store the list of accounts
        
			// 2. Create a scanner object and details it as sc to read the input from keyboard
                        
			//   while (iterate) {  
				// 3. Read the values account type, first details, last details, date of birth from the input file
				// 4. Create an Account object.
				// 5. For each record upon on account type, initalize the multiple argument constructor.
				// 6. Print full details of the c1omer.
				// 7. while(Iterate){
				//     a. Read trasaction and a create transaction object by initalizing the multiple argument constructor.
				//     b. Using a try-catch block, print balance after each transaction by including transaction type. 
				// 	}
				// 10. Add Account object to accounts Arraylist.
			// } 
        // Print "Invoke getNoofWithdrawals() on SavingsAccount objects"
        // 11(a). For each Account from accounts, invoke getNoofWithdrawals() method on SavingsAccount objects
		// 11(b). Print number of withdrawls made in this month for each account.

        // Print "Invoke generateStatement() on all objects in accounts ArrayList"
        // 12. Invoke generateStatement() method on all objects in accounts ArrayList and print all account statements

        ArrayList<Account> accounts = new ArrayList<>();
        Scanner sc=new Scanner(new File("input.txt"));
        DecimalFormat dformt = new DecimalFormat("##0.00");
         String stline = "";
        String typeofacc = null;
        while (sc.hasNextLine()) {
            if (typeofacc == null) {
                typeofacc = sc.nextLine();
            } else {
                typeofacc = stline;
            }
           // String typeofacc=sc.nextLine();
            
            String[] details = null;
            details = sc.nextLine().split(" ");
            String personfName = details[0];
            String personlName = details[1];
            String perdob = sc.nextLine();
            Customer c1=new Customer(personfName, personlName, perdob);
            Account a1;
            Long a1num=sc.nextLong();
            boolean amountwithdraw;
            if(typeofacc.equalsIgnoreCase("savings")){
               amountwithdraw =sc.nextBoolean();
            sc.nextLine();
                a1=new SavingsAccount(c1, a1num,amountwithdraw );
            }
            else {
                sc.nextLine();
                a1=new CurrentAccount(c1, a1num);
            }
            System.out.println("------------------------------------------------------------");
            System.out.println("Name of the c1omer: " + personfName + " " + personlName);
            System.out.println("------------------------------------------------------------");
            stline = sc.nextLine();
            
            while (!(stline.equalsIgnoreCase("savings")||stline.equalsIgnoreCase("current"))) {
                String[] transInfo = stline.split(" ", 3);
                String tType = transInfo [0];
                double tamount = Double.valueOf(transInfo [1]);
                String date = transInfo [2];
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-M-d H:m:s");
                LocalDateTime tDate = LocalDateTime.parse(date, formatter);
                String ttype=transInfo [0];
                
                Transaction trans = new Transaction(TransactionType.valueOf(ttype), tamount, tDate);
                try{
                    a1.makeTransaction(trans);
                    System.out.println("The balance after " + tType + " in dollars is " + dformt.format(a1.getBalance()));  
                }
            catch(Exception e){
                System.out.println(e);
            }
                if (sc.hasNextLine()) {
                    stline = sc.nextLine();
                } else {
                    break;
                }
               
            }
             accounts.add(a1);
        }
        System.out.println("************************");
        System.out.println("****Invoke getNoofWithdrawals() on SavingsAccount objects***");
        System.out.println("************************");
        for (Account a1 : accounts) {
            if (a1.toString().contains("Savings")) {
                SavingsAccount s1act = (SavingsAccount) a1;
                System.out.println(a1.getCustomer().getFirstName() + " made " + s1act.getNoofWithdrawals() + " withdrawals in this month.");
            }
        }
        System.out.println("*************************");
        System.out.println("*Invoke generateStatement() on all objects in accounts ArrayList*");
        System.out.println("************************");
        for (Account a1 : accounts) {
            System.out.println(a1.generateStatement());
        }
    }
    
}
