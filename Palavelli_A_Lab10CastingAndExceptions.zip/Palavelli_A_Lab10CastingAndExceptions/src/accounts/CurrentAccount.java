/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

import enums.TransactionType;
import exceptions.OverdraftLimitExceededException;
import interfaces.Operations;
import java.text.DecimalFormat;

/**
 *
 * @author S549406
 */
public class CurrentAccount extends Account{
     DecimalFormat dformt = new DecimalFormat("###.00");
     
     public CurrentAccount(Customer customer, long accountNumber){
        super(customer, accountNumber);
    }
    
     public String generateStatement(){
        if(super.getBalance()>0.0){
        return super.generateStatement()+"Current Balance: "+dformt.format(super.getBalance())+"\n" +
"Overdraft usage: $0.00    Overdraft available: $"+dformt.format(Operations.OVERDRAFT_LIMIT)+"\n"
                + "***************************";
        
        }
        else{
       return super.generateStatement()+"Current Balance: 0.00\n" +
"Overdraft usage: $"+dformt.format(Operations.OVERDRAFT_LIMIT-(Operations.OVERDRAFT_LIMIT+super.getBalance()))+"    Overdraft available: $"+dformt.format(Operations.OVERDRAFT_LIMIT+super.getBalance())+"\n"
                + "***************************";
         }
    }
     
     @Override
    public double makeTransaction(Transaction transaction) throws Exception {
        double availbal = super.getBalance() + Operations.OVERDRAFT_LIMIT;
       if(transaction.getTransactionType().equals(TransactionType.WITHDRAW)||transaction.getTransactionType().equals(TransactionType.ONLINEPURCHASE)){
        if(availbal<transaction.getAmount()){
           transaction.setAdditionalCharges(0.0);
           transaction.setStatus("FAILED");
           transactions.add(transaction);
           throw new OverdraftLimitExceededException();  
        }      
    }
       if(transaction.getTransactionType().equals(TransactionType.DEPOSIT)){
             transaction.setAdditionalCharges(0.0);
             transaction.setStatus("SUCCESS");
             transactions.add(transaction);
             balance=balance+transaction.getAmount();
             return balance;
          }
      if(availbal>transaction.getAmount()){
          if(transaction.getTransactionType().equals(TransactionType.WITHDRAW)){
             transaction.setAdditionalCharges(0.0);
             transaction.setStatus("SUCCESS");
             transactions.add(transaction);
             
             balance=balance-transaction.getAmount();
             return balance;
          }
          
          else if(transaction.getTransactionType().equals(TransactionType.ONLINEPURCHASE)){
             transaction.setAdditionalCharges(1.59);
             transaction.setStatus("SUCCESS");
             transactions.add(transaction);
             balance=balance-transaction.getAmount()-transaction.getAdditionalCharges();
             return balance;
          }
      } 
    return 0.0;
    
}
   public String toString(){
       return super.toString()+"\nAccount Type: Current Account	Overdraft Limit: $"+dformt.format(Operations.OVERDRAFT_LIMIT);

    
    }
    
}
