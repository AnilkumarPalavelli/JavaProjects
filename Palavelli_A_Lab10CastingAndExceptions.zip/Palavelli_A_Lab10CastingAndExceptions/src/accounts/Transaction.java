/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

import enums.TransactionType;
import java.time.LocalDateTime;

/**
 *
 * @author S549406
 */
public class Transaction {
    public double amount;
    public double additionalCharges;
    public String status;
    public TransactionType transactionType;
    public LocalDateTime transactionTime;
    
    public Transaction(TransactionType transactionType, double amount, LocalDateTime transactionTime) {
        this.amount = amount;
        this.transactionTime = transactionTime;
        this.transactionType = transactionType;
    }

    public double getAmount() {
        return amount;
    }

    public double getAdditionalCharges() {
        return additionalCharges;
    }

    public String getStatus() {
        return status;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public LocalDateTime getTransactonTime() {
        return transactionTime;
    }

    public void setAdditionalCharges(double additionalCharges) {
        this.additionalCharges = additionalCharges;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    

    
    

    @Override
    public String toString() {
        return String.format("%-20s", transactionType)+ String.format("%-25s", transactionTime)+ "$"+String.format("%-16s", String.format("%.2f", amount))+"$"+ String.format("%-25s", String.format("%.2f", additionalCharges))+ String.format("%-10s", status);
    }

    
    
}
