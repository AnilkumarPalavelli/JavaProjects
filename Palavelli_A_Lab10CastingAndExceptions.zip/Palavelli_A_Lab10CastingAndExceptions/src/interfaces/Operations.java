/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import accounts.Transaction;

/**
 *
 * @author S549406
 */
public interface Operations {
    static final double OVERDRAFT_LIMIT=500.0;
    
    static final double SAVING_INTEREST=5.8;
    
    public abstract String generateStatement();
    
    public abstract double makeTransaction(Transaction transaction)throws Exception;
    
}
