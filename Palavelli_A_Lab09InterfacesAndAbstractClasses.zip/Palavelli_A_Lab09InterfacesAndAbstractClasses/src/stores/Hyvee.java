/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stores;

import java.util.Scanner;

/**
 * 
 * @author Anilkumar Palavelli_S549406
 */
public class Hyvee implements Grocery {
    
      private double total;

    
    public Hyvee() {
        total = 0.0;
    }

    
    @Override
    public void buyItems() {
        boolean moreItem = true;
        String itemsadded;
        Scanner sc = new Scanner(System.in);
        double price = 0.0;
        String Name;
        while (moreItem) {
            System.out.print("\nEnter the name of item:");
            Name = sc.next();
            System.out.print("\nEnter the price of " + Name + ":");
            price = sc.nextDouble();
            total = total + price;
            System.out.print("\nDo you want to buy more items (Y/N):");
            itemsadded = sc.next();
            if (itemsadded.equalsIgnoreCase("Y")) {
                moreItem = true;
            } else {
                moreItem = false;
            }

        }
    }

    @Override
    public double getTotal() {
        return total;
    }
    
}
