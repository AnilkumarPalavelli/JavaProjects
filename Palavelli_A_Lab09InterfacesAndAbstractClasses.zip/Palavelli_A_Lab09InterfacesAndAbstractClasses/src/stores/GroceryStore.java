/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stores;

/**
 *GroceryStore class
 * @author Anilkumar Palavelli_S549406
 */
public class GroceryStore extends Store {
/**
 * This method returns the groceryStore based on the valued passed by us
 * @param name
 * @return gro
 */
    @Override
    public Grocery createGroceryStore(String name) {
        Grocery gro=null;
        if (name.equalsIgnoreCase("Wallmart")) {
            gro = new WallMart();
        } else {
            gro= new Hyvee();
        }
        return gro;
    }
/**
 * This method returns the medicine based on the value passed in the string
 * @param name
 * @return null
 */
    @Override
    public Medicine createMedicineStore(String name) {
        return null;
       
    }
    
   
    
}
