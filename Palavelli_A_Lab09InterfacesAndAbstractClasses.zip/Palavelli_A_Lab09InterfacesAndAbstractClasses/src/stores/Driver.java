/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stores;

import java.util.Scanner;

/**
 *Driver Class 
 * @author Anilkumar Palavelli_S549406
 */
public class Driver {

    /**
     * The Main Method in the Driver class
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner sc=new Scanner(System.in);
        Creator creat =new Creator();
        String storeType;
        System.out.print("Enter what you want to buy (Grocery/Medicine):");
        storeType=sc.next();
        Store stor = creat.createStore(storeType);
        String storeName;
        if(storeType.equalsIgnoreCase("Grocery")){
            System.out.print("\nEnter the grocery store name from which you want to buy (Wallmart/Hyvee):");
            storeName=sc.next();
            Grocery gro =stor.createGroceryStore(storeName);
            gro.buyItems();
            System.out.print("\nTotal price for the shopping is:"+gro.getTotal());
            System.out.println("\n***********************************************************************");
            System.out.println("***********************************************************************");
        }
        else{
            System.out.print("\nEnter the medicine store name from which you want to buy (Wallgreen/Mosaic):");
            storeName=sc.next();
            Medicine medicin=stor.createMedicineStore(storeName);
            medicin.buyItems();
            System.out.println("\nTotal price for the shopping is:"+medicin.getTotal());
            
        } 
    }
    
}
