/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stores;

/**
 *Creator class
 * @author Anilkumar Palavelli_S549406
 */
public class Creator {
    /**
     * This method returns the store object based on the value passed
     * @param name
     * @return store
     */
    
    public Store createStore(String name){
        Store store=null;
        if(name.equalsIgnoreCase("Grocery")){
            store=new GroceryStore();
        }
        else{
            store=new MedicineStore();
        }
        return store;
    }

    
    
}
