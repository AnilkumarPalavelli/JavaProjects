/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stores;

/**
 *MedicineStore class extends Store
 * @author Anilkumar Palavelli_S549406
 */
public class MedicineStore extends Store {
    
    public Grocery createGroceryStore(String name) {
        return null;
    }

    
    public Medicine createMedicineStore(String name) {
        Medicine medicine;
        if (name.equalsIgnoreCase("WallGreen")) {
            medicine = new WallGreen();
        } else {
            medicine = new Mosaic();
        }
        return medicine;
    }
}
