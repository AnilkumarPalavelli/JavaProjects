
package MobilePrice;

/**
 *
 * @author Anilkumar Palavelli_S549406
 */
public class ProviderCalculator {
    private String providerName;
    private int numOfUsers;
    private Boolean isMemberOfMobileAlliance;
    private char isFirstTimeUser;
    private String hasCoupon;
    private double COUPON=5.00;
    private double SALETAXES=7.50;
    
    /**
     * Creating one constructor with providerName,numofUsers,isMemberOfMobileAlliance,isFirstTimeUser,hasCoupon
     * @param providerName
     * @param numOfUsers
     * @param isMemberOfMobileAlliance
     * @param isFirstTimeUser
     * @param hasCoupon 
     */
    
    

    public ProviderCalculator(String providerName, int numOfUsers, Boolean isMemberOfMobileAlliance, char isFirstTimeUser, String hasCoupon) {
        this.providerName = providerName;
        this.numOfUsers = numOfUsers;
        this.isMemberOfMobileAlliance = isMemberOfMobileAlliance;
        this.isFirstTimeUser = isFirstTimeUser;
        this.hasCoupon = hasCoupon;
    }
    /**
     * getter method returns the providerName
     * @return providerName 
     */

    public String getProviderName() {
        return providerName;
    }
    /**
     * getter method returns the numOfUsers
     * @return numOfUsers
     */
    public int getNumOfUsers() {
        return numOfUsers;
    }
    /**
     * getter method returns the isMemberOfMobileAlliance
     * @return isMemberOfMobileAlliance 
     */
    public Boolean getIsMemberOfMobileAlliance() {
        return isMemberOfMobileAlliance;
    }
    /**
     * getter method returns the isFirstTimeUser
     * @return 
     */
    public char getIsFirstTimeUser() {
        return isFirstTimeUser;
    }
    /**
     * getter method returns the hasCoupon 
     * @return 
     */
    public String getHasCoupon() {
        return hasCoupon;
    }
    /**
     * setter method sets the provider name
     * @param providerName 
     */
    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }
    /**
     * setter method sets the numOfUsers
     * @param numOfUsers 
     */
    public void setNumOfUsers(int numOfUsers) {
        this.numOfUsers = numOfUsers;
    }
    /**
     * setter method sets the isMemberOfMobileAlliance
     * @param isMemberOfMobileAlliance 
     */
    public void setIsMemberOfMobileAlliance(Boolean isMemberOfMobileAlliance) {
        this.isMemberOfMobileAlliance = isMemberOfMobileAlliance;
    }
    /**
     * setter method sets the isFirstTimeUser
     * @param isFirstTimeUser 
     */
    public void setIsFirstTimeUser(char isFirstTimeUser) {
        this.isFirstTimeUser = isFirstTimeUser;
    }
    /**
     * setter method sets the hasCoupon
     * @param hasCoupon 
     */
    public void setHasCoupon(String hasCoupon) {
        this.hasCoupon = hasCoupon;
    }

    
    /**
     *toString method returns the providerName,numOfUsers,isMemberOfMobileAlliance,isFirstTimeUser,hasCoupon 
     * @return 
     */
    @Override
    public String toString() {
        return  "providerName=" + providerName + ", \nnumOfUsers=" + numOfUsers + ", \nisMemberOfMobileAlliance=" + isMemberOfMobileAlliance + ", \nisFirstTimeUser=" + isFirstTimeUser + ", \nhasCoupon=" + hasCoupon ;
    }
    /**
     * This method checks the providerName using Switch
     * @param ProviderName
     * @return 
     */
    public Boolean checkProviderName(String ProviderName ){
        Boolean checkProviderName;
        switch(providerName){
            case "AT&T":
                checkProviderName=true;
                break;
            case "T-Mobile":
                checkProviderName=true;
                break;
            case "Verizon":
                checkProviderName=true;
                break;
            default:
                checkProviderName=false;
        }
        return checkProviderName;
    }
    /**
     * This method calculate the ProviderPrice using if else statements
     * @return 
     */
    private double calcProviderPrice(){
        double price=0.0;
        if(providerName.equals("AT&T"))
        {
            if(numOfUsers==1)
            {
               price=30.99;
            }
            else if(numOfUsers==2)
            {
                price=52.99;
            }
            else if(numOfUsers>=3&&numOfUsers<=5)
            {
                price=20.99;
            }
        }
        else if(providerName.equals("T-Mobile"))
        {
            if(numOfUsers==1)
            {
               price=39.99;
            }
            else if(numOfUsers==2)
            {
                price=70.99;
            }
            else if(numOfUsers>=3&&numOfUsers<=5)
            {
                price=29.99;
            }
        }
         else if(providerName.equals("Verizon"))
        {
            if(numOfUsers==1)
            {
               price=43.99;
            }
            else if(numOfUsers==2)
            {
                price=75.99;
            }
            else if(numOfUsers>=3&&numOfUsers<=5)
            {
                price=33.99;
            }
        }
       return price*numOfUsers;
    }
    /**
     * This Method calculate the MembershipDiscount using if else statements 
     * @return 
     */
     private double calcMembershipDiscount()
    {
        double discount=0.0;
        if(checkProviderName(providerName)&&isMemberOfMobileAlliance)
        {
            if(numOfUsers==1)
            {
                discount=calcProviderPrice()*7.5/100;
            }
            else if(numOfUsers==2)
            {
                discount=calcProviderPrice()*6.5/100;
            }
            else if(numOfUsers>=3&&numOfUsers<=5)
            {
               discount=calcProviderPrice()*8.5/100; 
            }
        }
        return discount;
    }
     /**
      * This method calculate the firstTimeUserDiscount using if else
      * @return 
      */
     private double calcFirstTimeUserDiscount()
    {
        double userDiscount=0.0;
        if(checkProviderName(providerName )&&isFirstTimeUser=='Y')
        {
           if(numOfUsers==1)
           {
               userDiscount=calcProviderPrice()*10/100;
           }
           else if(numOfUsers==2)
           {
               userDiscount=calcProviderPrice()*5/100;
           }
           else if(numOfUsers>=3&&numOfUsers<=5)
           {
               userDiscount=calcProviderPrice()*4/100;
           }
        }
        return userDiscount;
    }
    private double chooseYourDiscount() 
    {
        if(isMemberOfMobileAlliance)
            return calcMembershipDiscount();
        else if(isFirstTimeUser=='Y')
        {
            return calcFirstTimeUserDiscount();
        }
        else if(hasCoupon.equals("Yes"))
        {
            return COUPON;
        }
       
        return 0.0;
    }
    /**
     * This method calculates the coupon discount
     * @return 
     */
    private double calcCouponDiscount()
    { 
        if(hasCoupon.equals("Yes"))
        {
        return COUPON;
        }
        return 0.0;
    }
    /**
     * This method calculates the totalPrice
     * @return 
     */
     private double totalPrice()
    {
        double totalprice=calcProviderPrice()-chooseYourDiscount();
        return totalprice;
    }
   /**
    * This method calculate the totalpricewithSalesTax
    * @return 
    */
    private double  totalPriceWithSalesTax()
    {
        double totalpricewithtax=totalPrice()+SALETAXES*totalPrice()/100;
        return totalpricewithtax;
    
    }
    public String printReceipt()
    {
        return "              ++++ Receipt ++++"
                + "\nMobile Charges for"+numOfUsers+" user using "+providerName+ "as provider is: $" + calcProviderPrice()
                + "\nMember of the Mobile Alliance: $" +Math.round(calcMembershipDiscount()*100.0)/100.0
                + "\nFirst Time user discount: $"+Math.round(calcFirstTimeUserDiscount()*100.0)/100.0
                +"\nCoupon Discount: $"+Math.round(calcCouponDiscount()*100.0)/100.0
                +"\nCharges After applying Discount: $"+Math.round(totalPrice()*100.0)/100.0
                + "\nTotal Price with Tax: $" +Math.round(totalPriceWithSalesTax()*100.0)/100.0;
    }
   
}

    

                
                
                
                
                
            
        
  
    
    
    
