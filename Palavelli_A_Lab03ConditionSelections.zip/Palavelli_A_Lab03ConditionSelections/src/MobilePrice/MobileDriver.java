
package MobilePrice;
import java.util.Scanner;

/**
 *This class is driver class for ProviderCalculator class
 * @author Anilkumar Palavelli_S549406
 */
public class MobileDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i=1;
        Scanner scan=new Scanner(System.in);
        //created a scanner class interface
        System.out.println("            Enter User Details:");
   
       
        System.out.print("Select the provider’s name: AT&T, T-Mobile, Verizon: ");
        String providerName=scan.nextLine();
        
        System.out.print("How many number of users: ");
        int numOfUsers=scan.nextInt();
        
        System.out.print("Are you a member of the Mobile Alliance: ");
        boolean isMemberOfMobileAlliance=scan.nextBoolean();
        
        System.out.print("Are you a first time user: ");
        char isFirstTimeUser=scan.next().charAt(0);
        
        System.out.print("Do you have coupon: ");
        scan.nextLine();
        String hasCoupon=scan.nextLine();
        
        System.out.println("****************************************************");
        
         ProviderCalculator pc=new ProviderCalculator(providerName,numOfUsers,isMemberOfMobileAlliance,isFirstTimeUser,hasCoupon);
        //Created a new object providecalculator named as pc
        if(!pc.checkProviderName(providerName))
        {
            System.out.println("Error#"+i+"Not a valid provider's name");
            i=i+1;
            
        }
        if(numOfUsers==0)
        {
            System.out.println("Error#"+i+"The number of users can't be zero.");
            i=i+1;
            
        }
        if(numOfUsers>5)
        {
            System.out.println("Error#"+i+"The number of users should be between 3 and 5.");
            i=i+1;
            
        }
        if(isMemberOfMobileAlliance)
        {
            if(isFirstTimeUser=='Y'||hasCoupon.equals("yes"))
                    {
                        System.out.println("Error#"+i+": User can only use one discount: (1)  Member of the Mobile Alliance, (2) First Time User, or (3) has a coupon at a time."); 
                        
                        System.out.println("You are required to choose only one option: (1), (2) or (3)");
                        i=i+1;
                    }
           
        }
        else if(isFirstTimeUser=='Y')
        {
            if(isMemberOfMobileAlliance || hasCoupon.equals("yes"))
            {
                System.out.println("Error#"+i+": User can only use one discount: (1)  Member of the Mobile Alliance, (2) First Time User, or (3) has a coupon at a time.");
                
                System.out.println("You are required to choose only one option: (1), (2) or (3)");
                i=i+1;
            }
        }
        if(i>1)
        {
            System.out.println("Please try again");
          
        }
        else{
       
          System.out.println("          User Provider Details :\n"+pc);
            System.out.println("************************************************");
            System.out.println(pc.printReceipt());
    }
    
}
}
        
        
    
    

