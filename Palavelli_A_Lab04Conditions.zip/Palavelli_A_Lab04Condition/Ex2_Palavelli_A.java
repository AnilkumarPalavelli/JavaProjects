/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercises;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author Anilkumar Palavelli_S549406
 */
public class Ex2_Palavelli_A {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        
        // TODO code application logic here
        Scanner num=new Scanner(new File("lab4datafile.txt"));
        PrintWriter oddnumber =new PrintWriter(new File("odd.txt"));
        PrintWriter  evennumber=new PrintWriter(new File("even.txt"));
        PrintWriter  divseven=new PrintWriter(new File("seven.txt "));
        int oddnumbercount=0;
         int evennumbercount=0;
         int sevencount=0;
         while(num.hasNext()){
             int i=num.nextInt();
             if(i%2==0){
                 evennumber.println(i);
                 evennumbercount++;
                 
             }
             
             else 
             {
                 oddnumber.println(i);
                 oddnumbercount++;
                 
             }
             if (i%7==0)
             {
                divseven.println(i);
                sevencount++;
                
             }
             
         }
         System.out.println("Number  of  odd  numbers:  "+oddnumbercount);
         System.out.println("Number  of  even  numbers : "+evennumbercount);
         System.out.println("Number of numbers divisible by 7: "+sevencount);
         
         
    }
    private static boolean IsDivisibleby7 (int n ){
        
        int ud;
        int remnum;
        ud=n%10;
        remnum=n/10;
        if((remnum)-(ud)%7==0)
            return true;
        return false;
    }
        }
    

        
            
        
   
    
        
        
            
 
        
  
    
    
    
