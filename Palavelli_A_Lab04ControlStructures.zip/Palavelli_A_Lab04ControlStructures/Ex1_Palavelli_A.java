package exercises;

import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Anilkumar Palavelli_S549406
 */
public class Ex1_Palavelli_A {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        final double TAX_RATE = 0.08;
        double pricewithDicount=0.0;
        double pricewithToppings=0.0;
        System.out.println("             ***** Welcome to Zombie's  & Gombie ***** ");
        Scanner cus = new Scanner(System.in);
        System.out.print("What is your  name?");
        String name = cus.nextLine();
        System.out.println("Pizza Size (inches)  Cost\n"
                + "        10            $10.99\n"
                + "        12            $12.99\n"
                + "        14            $14.99\n"
                + "        16            $16.99");
        System.out.println("What size of pizza would you like?");
        System.out.print("10\", 12\", 14\", or 16\" (Enter one size only):");
        int size = cus.nextInt();
        cus.nextLine();
        System.out.println("Are you a student? ");
        char student = cus.nextLine().charAt(0);
        if (student == 'Y' || student == 'y') {
            System.out.println("You are eligible for a $2.00 discount");
        }
        System.out.println("What type of crust would you like to have?");
        System.out.print("(T) Thin Crust, (O) Original Crust , or (S) Skillet Crust(enter T, O, or S):");
        char crust = cus.nextLine().charAt(0);
        System.out.println("All pizzas come with cheese.\n"
                + "Additional toppings are $0.75 each, choose from:\n"
                + "Beef, Tomatoes, Black Olives,  Mushrooms, Green Peppers ");
        System.out.print("Would you like to add beef?(Y/N): ");
        char beef = cus.next().charAt(0);
        System.out.print("Would you like to add Tomatoes?(Y/N): ");
        char tomatoes=cus.next().charAt(0);
        System.out.print("Would you like to add Black Olives? (Y/N): ");
        char olives=cus.next().charAt(0);
        System.out.print("Would you like to add Mushrooms (Y/N): ");
        char mushrooms=cus.next().charAt(0);
        System.out.print("Would you like to add Green Peppers (Y/N): ");
        char greenPeppers=cus.next().charAt(0);
        System.out.println("-> Your order is as follows: ");
        System.out.println("->"+size+" inch pizza");
        
       String crustType=null;
        switch(crust){
            case 'S':
            crustType="Skillet";
            break;
            case 'T' :
            crustType="Thin";
            break;
            case 'O' :
            crustType="Original";
            break;
        }
        System.out.println("->"+crustType+" Crust");
        System.out.print("Cheese,");
        int i=0;
        if (beef=='Y'||beef=='y') 
        {
            System.out.print("Beef,");
            i+=1;
        }
        if (tomatoes=='Y'||tomatoes=='y')
        {
            System.out.print("Tomatoes,");
            i+=1;
        }
        if (olives=='Y'||olives=='y')
        {
            System.out.print("Black Olives,");
            i+=1;
        }
         if (mushrooms=='Y'||mushrooms=='y')
        {
            System.out.print("Mushrooms,");
            i+=1;
        }
          if (greenPeppers=='Y'||greenPeppers=='y')
        {
            System.out.println("Green Peppers");
            i+=1;
        }
          double price=0.0;
          
        switch (size) {
            case 10:
                price=10.99;
                break;
            case 12:
                price=12.99;
                break;
            case 14:
                price=14.99;
                break;
            case 16:
                price=16.99;
                break;
            default:
                break;
        } 
        if(student=='Y' || student=='y')
            pricewithDicount=price-2.0;
        
        pricewithToppings=pricewithDicount+3*0.75;
        System.out.println("The cost of your order is: $"+pricewithToppings);
        double taxtoPay;
        taxtoPay=TAX_RATE*pricewithToppings;
        System.out.println("The tax is: $"+Math.round(taxtoPay*100.0)/100.0);
        double finalamount;
        finalamount=pricewithToppings+taxtoPay;
        System.out.println("->The total due is:  $"+Math.round(finalamount*100.0)/100.0);
        System.out.println("->Enjoy your Pizza and your order will be ready  in 20 minutes.");
        
        
    
        
    }
    
}
        
        
    
        
   
                
        

